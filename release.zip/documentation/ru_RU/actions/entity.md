<h2 id=entity>
  <code>entity</code>
  <a href="./actions.md" style="font-size: 14px; margin-left:">↩️</a>
</h2>

| **ID**             | **Название**          |
|--------------------|-----------------------|
| `<current>`        | Текущая цель          |
| `<default_entity>` | Сущность по умолчанию |
| `<killer_entity>`  | Убийца                |
| `<damager_entity>` | Атакующая сущность    |
| `<shooter_entity>` | Стрелок               |
| `<projectile>`     | Снаряд стрелка        |
| `<victim_entity>`  | Жертва                |
| `<random_entity>`  | Случайная сущность    |
| `<all_mobs>`       | Все мобы              |
| `<all_entities>`   | Все сущности          |
| `<last_entity>`    | Последняя сущность    |


**Важно:** эти селекторы доступны только для действий от объекта `entity`.

<h3 id=entity_attach_lead>
  <code>entity::attach_lead</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Привязать на поводок\
**Тип:** Действие без значения\
**Описание:** Привязывает существо на поводок к забору или существу.\
**Дополнительная информация:**\
&nbsp;&nbsp;Если длина поводка будет больше 10 блоков, то поводок порвётся.

**Пример использования:**
```ts
entity::attach_lead("name_or_uuid", location(0,0,0,0,0));

//Или в сухую по ключам

entity::attach_lead(name_or_uuid="name_or_uuid", location=location(0,0,0,0,0));
```

**Аргументы:**

| ID           | Тип            | Описание              |
|--------------|----------------|-----------------------|
| name_or_uuid | Текст          | Имя существа или UUID |
| location     | Местоположение | Местоположение забора |

<h3 id=entity_celar_potion_effects>
  <code>entity::clear_potion_effects</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Очистить эффекты\
**Тип:** Действие без значения\
**Описание:** Очищает все эффекты у существа.

**Пример использования:**
```ts
entity::clear_potion_effects();
```

<h3 id=entity_clear_merchant_recipes>
  <code>entity::clear_merchant_recipes</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Очистить торги Жителю\
**Тип:** Действие без значения\
**Описание:** Очищает все торги Жителю.\
**Работает с:**\
&nbsp;&nbsp;Жителями\
&nbsp;&nbsp;Странствующими торговцами

**Пример использования:**
```ts
entity::clear_merchant_recipes();
```

<h3 id=entity_complete_using_active_item>
  <code>entity::complete_using_active_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Завершить использование предмета\
**Тип:** Действие без значения\
**Описание:** Завершает использование текущего предмета в руке с результатом.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::complete_using_active_item();
```

<h3 id=entity_damage>
  <code>entity::damage</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Нанести урон\
**Тип:** Действие без значения\
**Описание:** Наносит урон существу.

**Пример использования:**
```ts
entity::damage(1, "source");

//Или в сухую по ключам

entity::damage(damage=1, source="source");
```

**Аргументы:**

| ID     | Тип   | Описание                               |
|--------|-------|----------------------------------------|
| damage | Число | Количество урона                       |
| source | Текст | Источник урона (имя или UUID существа) |

<h3 id=entity_disguise_as_block>
  <code>entity::disguise_as_block</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Замаскировать сущность под блок\
**Тип:** Действие без значения\
**Описание:** Маскирует сущность под блок.

**Пример использования:**
```ts
entity::disguise_as_block("minecraft:oak_log[axis=x]");

//Или в сухую по ключам

entity::disguise_as_block(block="minecraft:oak_log[axis=x]");
```

**Аргументы:**

| ID    | Тип  | Описание            |
|-------|------|---------------------|
| block | Блок | Блок для маскировки |

<h3 id=entity_disguise_as_entity>
  <code>entity::disguise_as_entity</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Замаскировать под сущность\
**Тип:** Действие без значения\
**Описание:** Замаскировать сущность под сущность.

**Пример использования:**
```ts
entity::disguise_as_entity(item("stick"));

//Или в сухую по ключам

entity::disguise_as_entity(entity_type=item("stick"));
```

**Аргументы:**

| ID          | Тип     | Описание                |
|-------------|---------|-------------------------|
| entity_type | Предмет | Сущность для маскировки |

<h3 id=entity_disguise_as_item>
  <code>entity::disguise_as_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Замаскировать сущность под предмет\
**Тип:** Действие без значения\
**Описание:** Маскирует сущность под предмет.

**Пример использования:**
```ts
entity::disguise_as_item(item("stick"));

//Или в сухую по ключам

entity::disguise_as_item(item=item("stick"));
```

**Аргументы:**

| ID   | Тип     | Описание               |
|------|---------|------------------------|
| item | Предмет | Предмет для маскировки |

<h3 id=entity_disguise_as_player>
  <code>entity::disguise_as_player</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Замаскировать сущность под игрока\
**Тип:** Действие без значения\
**Описание:** Маскирует сущность под игрока.

**Пример использования:**
```ts
entity::disguise_as_player("name_or_uuid", "display_name", "MOJANG");

//Или в сухую по ключам

entity::disguise_as_player(name_or_uuid="name_or_uuid", display_name="display_name", server_type="MOJANG");
```

**Аргументы:**

| ID           | Тип                                                              | Описание                            |
|--------------|------------------------------------------------------------------|-------------------------------------|
| name_or_uuid | Текст                                                            | Имя, UUID или ссылка на изображение |
| display_name | Текст                                                            | Отображаемое имя сущности           |
| server_type  | Маркер<br/>**MOJANG** - Скин Mojang<br/>**SERVER** - Скин JustMC | Тип сервера скинов                  |

<h3 id=entity_dummy>
  <code>entity::dummy</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** ...\
**Тип:** Действие без значения\
**Описание:** ...

**Пример использования:**
```ts
entity::dummy();
```

<h3 id=entity_eat_grass>
  <code>entity::eat_grass</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Есть траву\
**Тип:** Действие без значения\
**Описание:** Заставляет овцу есть траву.\
**Работает с:**\
&nbsp;&nbsp;Овцами

**Пример использования:**
```ts
entity::eat_grass();
```

<h3 id=entity_eat_target>
  <code>entity::eat_target</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цель поедания\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу цель для поедания.\
**Работает с:**\
&nbsp;&nbsp;Жабами

**Пример использования:**
```ts
entity::eat_target("name_or_uuid");

//Или в сухую по ключам

entity::eat_target(name_or_uuid="name_or_uuid");
```

**Аргументы:**

| ID           | Тип   | Описание          |
|--------------|-------|-------------------|
| name_or_uuid | Текст | Имя или UUID цели |

<h3 id=entity_explode>
  <code>entity::explode</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Взорваться\
**Тип:** Действие без значения\
**Описание:** Заставляет существо взорваться.\
**Работает с:**\
&nbsp;&nbsp;Криперами\
&nbsp;&nbsp;Динамитом\
&nbsp;&nbsp;Фейерверками

**Пример использования:**
```ts
entity::explode();
```

<h3 id=entity_face_location>
  <code>entity::face_location</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Повернуть к местоположению\
**Тип:** Действие без значения\
**Описание:** Поворачивает существо в сторону к местоположению.

**Пример использования:**
```ts
entity::face_location(location(0,0,0,0,0));

//Или в сухую по ключам

entity::face_location(location=location(0,0,0,0,0));
```

**Аргументы:**

| ID       | Тип            | Описание       |
|----------|----------------|----------------|
| location | Местоположение | Местоположение |

<h3 id=entity_get_attribute>
  <code>entity::get_attribute</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Получить значение атрибута сущности\
**Тип:** Действие, возращающее значение\
**Описание:** Получает значение указанного атрибута сущности и присваивает результат к переменной.

**Пример использования:**
```ts
`variable` = entity::get_attribute("GENERIC_MAX_HEALTH", "VALUE");

//Или в сухую позиционно

entity::get_attribute(`variable`, "GENERIC_MAX_HEALTH", "VALUE");

//Или в сухую по ключам

entity::get_attribute(variable=`variable`, attribute_type="GENERIC_MAX_HEALTH", return_value="VALUE");
```

**Аргументы:**

| ID             | Тип                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Описание                  |
|----------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------|
| variable       | Переменная\[Число\]                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Переменная для присвоения |
| attribute_type | Маркер<br/>**GENERIC_MAX_HEALTH** - Максимальное здоровье (generic.max_health)<br/>**GENERIC_MAX_ABSORPTION** - Максимальное поглощение (generic.max_absorption)<br/>**GENERIC_FOLLOW_RANGE** - Расстояние следования (generic.follow_range)<br/>**GENERIC_KNOCKBACK_RESISTANCE** - Сопротивление отталкиванию (generic.knockback_resistance)<br/>**GENERIC_MOVEMENT_SPEED** - Скорость передвижения (generic.movement_speed)<br/>**GENERIC_FLYING_SPEED** - Скорость полёта (generic.flying_speed)<br/>**GENERIC_ATTACK_DAMAGE** - Урон атаки (generic.attack_damage)<br/>**GENERIC_ATTACK_KNOCKBACK** - Отталкивание атаки (generic.attack_knockback)<br/>**GENERIC_ATTACK_SPEED** - Скорость атаки (generic.attack_speed)<br/>**GENERIC_ARMOR** - Очки защиты (generic.armor)<br/>**GENERIC_ARMOR_TOUGHNESS** - Очки плотности защиты (generic.armor_toughness)<br/>**GENERIC_LUCK** - Удача рыбалки (generic.luck)<br/>**GENERIC_JUMP_STRENGTH** - Сила прыжка<br/>**GENERIC_FALL_DAMAGE_MULTIPLIER** - Множитель урона от падения<br/>**GENERIC_SAFE_FALL_DISTANCE** - Безопасная высота падения<br/>**GENERIC_SCALE** - Масштаб<br/>**GENERIC_STEP_HEIGHT** - Высота шага<br/>**GENERIC_GRAVITY** - Гравитация<br/>**PLAYER_BLOCK_INTERACTION_RANGE** - Расстояние взаимодействия с блоками<br/>**PLAYER_ENTITY_INTERACTION_RANGE** - Расстояние взаимодействия с сущностями<br/>**PLAYER_BLOCK_BREAK_SPEED** - Скорость ломания блока<br/>**GENERIC_BURNING_TIME** - Время горения<br/>**GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE** - Сопротивление отбрасыванию от взрыва<br/>**GENERIC_MOVEMENT_EFFICIENCY** - Скорость передвижения по замедляющим блокам<br/>**PLAYER_MINING_EFFICIENCY** - Скорость копания<br/>**PLAYER_SNEAKING_SPEED** - Скорость передвижения крадясь<br/>**PLAYER_SUBMERGED_MINING_SPEED** - Скорость копания под водой<br/>**PLAYER_SWEEPING_DAMAGE_RATIO** - Коэффициент разящего удара<br/>**GENERIC_OXYGEN_BONUS** - Воздух под водой<br/>**GENERIC_WATER_MOVEMENT_EFFICIENCY** - Скорость передвижения под водой<br/>**TEMP_RANGE** - Расстояние приманивания<br/>**WAYPOINT_TRANSMIT_RANGE** - Расстояние улавливания локатором (waypoint_transmit_range)<br/>**WAYPOINT_RECEIVE_RANGE** - Расстояние улавливания локатора (waypoint_receive_range)<br/>**CAMERA_DISTANCE** - Расстояние камеры при виде от третьего лица<br/>**ZOMBIE_SPAWN_REINFORCEMENTS** - Шанс подкрепления зомби (zombie.spawn_reinforcements) | Тип атрибута              |
| return_value   | Маркер<br/>**VALUE** - Текущее значение<br/>**BASE_VALUE** - Базовое значение<br/>**DEFAULT_VALUE** - Значение по умолчанию                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                | Тип значения              |

<h3 id=entity_get_custom_tag>
  <code>entity::get_custom_tag</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Получить кастомный тег\
**Тип:** Действие, возращающее значение\
**Описание:** Получает кастомный нбт-тег существа.

**Пример использования:**
```ts
`variable` = entity::get_custom_tag("name", "any value");

//Или в сухую позиционно

entity::get_custom_tag(`variable`, "name", "any value");

//Или в сухую по ключам

entity::get_custom_tag(variable=`variable`, name="name", default="any value");
```

**Аргументы:**

| ID       | Тип                          | Описание                  |
|----------|------------------------------|---------------------------|
| variable | Переменная\[Любое значение\] | Переменная для присвоения |
| name     | Текст                        | Имя тега                  |
| default  | Любое значение               | Значение по умолчанию     |

<h3 id=entity_get_equipment_item>
  <code>entity::get_equipment_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Получить снаряжение сущности\
**Тип:** Действие, возращающее значение\
**Описание:** Получает снаряжение сущности из указанного слота, и присваивает результат к переменной.

**Пример использования:**
```ts
`variable` = entity::get_equipment_item("HAND");

//Или в сухую позиционно

entity::get_equipment_item(`variable`, "HAND");

//Или в сухую по ключам

entity::get_equipment_item(variable=`variable`, slot="HAND");
```

**Аргументы:**

| ID       | Тип                                                                                                                                                                                                              | Описание                  |
|----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------|
| variable | Переменная\[Предмет\]                                                                                                                                                                                            | Переменная для присвоения |
| slot     | Маркер<br/>**HAND** - Основная рука<br/>**OFF_HAND** - Второстепенная рука<br/>**FEET** - Ботинки<br/>**LEGS** - Поножи<br/>**CHEST** - Нагрудник<br/>**HEAD** - Шлем<br/>**BODY** - Тело<br/>**SADDLE** - Седло | Слот снаряжения           |

<h3 id=entity_get_nbt>
  <code>entity::get_nbt</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Получить NBT-теги сущности\
**Тип:** Действие, возращающее значение\
**Описание:** Получает NBT-теги сущности по введённому пути и присваивает результат к переменной.

**Пример использования:**
```ts
`variable` = entity::get_nbt("path", "ANY_VALUE");

//Или в сухую позиционно

entity::get_nbt(`variable`, "path", "ANY_VALUE");

//Или в сухую по ключам

entity::get_nbt(variable=`variable`, path="path", value_type="ANY_VALUE");
```

**Аргументы:**

| ID         | Тип                                                                       | Описание                  |
|------------|---------------------------------------------------------------------------|---------------------------|
| variable   | Переменная\[Любое значение\]                                              | Переменная для присвоения |
| path       | Текст                                                                     | Путь                      |
| value_type | Маркер<br/>**ANY_VALUE** - Любое значение<br/>**NBT_STRING** - NBT-строка | Тип данных                |

<h3 id=entity_give_potion_effects>
  <code>entity::give_potion_effects</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Выдать эффекты\
**Тип:** Действие без значения\
**Описание:** Выдаёт выбранные эффекты существу.

**Пример использования:**
```ts
entity::give_potion_effects([potion("slow_falling"), potion("slow_falling")], "FALSE", "FALSE", "AMBIENT");

//Или в сухую по ключам

entity::give_potion_effects(potions=[potion("slow_falling"), potion("slow_falling")], overwrite="FALSE", show_icon="FALSE", particle_mode="AMBIENT");
```

**Аргументы:**

| ID            | Тип                                                                          | Описание                                                        |
|---------------|------------------------------------------------------------------------------|-----------------------------------------------------------------|
| potions       | Список\[Зелье\]                                                              | Эффекты для выдачи<br/>Аргумент поддерживает разложение списков |
| overwrite     | Маркер<br/>**FALSE** - Нет<br/>**TRUE** - Да                                 | Перезаписывать существующие эффекты                             |
| show_icon     | Маркер<br/>**FALSE** - Нет<br/>**TRUE** - Да                                 | Показывать иконку эффекта                                       |
| particle_mode | Маркер<br/>**AMBIENT** - Прозрачными<br/>**NONE** - Нет<br/>**REGULAR** - Да | Показывать частицы                                              |

<h3 id=entity_heal>
  <code>entity::heal</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Исцелить существо\
**Тип:** Действие без значения\
**Описание:** Исцеляет существо.

**Пример использования:**
```ts
entity::heal(1);

//Или в сухую по ключам

entity::heal(heal=1);
```

**Аргументы:**

| ID   | Тип   | Описание                                  |
|------|-------|-------------------------------------------|
| heal | Число | Количество половинок сердец для излечения |

<h3 id=entity_ignite_creeper>
  <code>entity::ignite_creeper</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Зажечь крипера\
**Тип:** Действие без значения\
**Описание:** Поджигает крипера, заставляя его взорваться после определённого периода.\
**Работает с:**\
&nbsp;&nbsp;Криперами

**Пример использования:**
```ts
entity::ignite_creeper();
```

<h3 id=entity_jump>
  <code>entity::jump</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Прыгнуть\
**Тип:** Действие без значения\
**Описание:** Заставляет существо прыгнуть.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::jump();
```

<h3 id=entity_launch_forward>
  <code>entity::launch_forward</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Запустить вперёд\
**Тип:** Действие без значения\
**Описание:** Запускает существо вперёд или назад по направлению взгляда в зависимости от силы.

**Пример использования:**
```ts
entity::launch_forward(1, "FALSE", "YAW");

//Или в сухую по ключам

entity::launch_forward(power=1, increment="FALSE", launch_axis="YAW");
```

**Аргументы:**

| ID          | Тип                                                                        | Описание                  |
|-------------|----------------------------------------------------------------------------|---------------------------|
| power       | Число                                                                      | Сила подбрасывания        |
| increment   | Маркер<br/>**FALSE** - Выключено<br/>**TRUE** - Включено                   | Учитывать текущую инерцию |
| launch_axis | Маркер<br/>**YAW** - Только по горизонтали<br/>**YAW_AND_PITCH** - Все оси | Ось запуска               |

<h3 id=entity_launch_projectile>
  <code>entity::launch_projectile</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Запустить снаряд\
**Тип:** Действие без значения\
**Описание:** Запустить снаряд из местоположения существа.

**Пример использования:**
```ts
entity::launch_projectile(item("stick"), location(0,0,0,0,0), "name", 1, 2, particle("fire"));

//Или в сухую по ключам

entity::launch_projectile(projectile=item("stick"), location=location(0,0,0,0,0), name="name", speed=1, inaccuracy=2, trail=particle("fire"));
```

**Аргументы:**

| ID         | Тип            | Описание                                         |
|------------|----------------|--------------------------------------------------|
| projectile | Предмет        | Снаряд для запуска                               |
| location   | Местоположение | Место запуска                                    |
| name       | Текст          | Имя снаряда                                      |
| speed      | Число          | Скорость снаряда                                 |
| inaccuracy | Число          | Отклонение снаряда (0, чтобы снаряд летел ровно) |
| trail      | Эффект частиц  | След, который будет оставаться за снарядом       |

<h3 id=entity_launch_to_location>
  <code>entity::launch_to_location</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Запустить к местоположению\
**Тип:** Действие без значения\
**Описание:** Запускает существа к выбранному местоположению.

**Пример использования:**
```ts
entity::launch_to_location(location(0,0,0,0,0), 1, "FALSE");

//Или в сухую по ключам

entity::launch_to_location(location=location(0,0,0,0,0), power=1, increment="FALSE");
```

**Аргументы:**

| ID        | Тип                                                      | Описание                  |
|-----------|----------------------------------------------------------|---------------------------|
| location  | Местоположение                                           | Конечная позиция          |
| power     | Число                                                    | Сила запуска              |
| increment | Маркер<br/>**FALSE** - Выключено<br/>**TRUE** - Включено | Учитывать текущую инерцию |

<h3 id=entity_launch_up>
  <code>entity::launch_up</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Подбросить вверх\
**Тип:** Действие без значения\
**Описание:** Подбрасывает существо вверх или вниз в зависимости от силы.

**Пример использования:**
```ts
entity::launch_up(1, "FALSE");

//Или в сухую по ключам

entity::launch_up(power=1, increment="FALSE");
```

**Аргументы:**

| ID        | Тип                                                      | Описание                  |
|-----------|----------------------------------------------------------|---------------------------|
| power     | Число                                                    | Сила подбрасывания        |
| increment | Маркер<br/>**FALSE** - Выключено<br/>**TRUE** - Включено | Учитывать текущую инерцию |

<h3 id=entity_leave_vehicle>
  <code>entity::leave_vehicle</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Высадить из транспорта\
**Тип:** Действие без значения\
**Описание:** Высаживает существо из транспорта или существа.

**Пример использования:**
```ts
entity::leave_vehicle();
```

<h3 id=entity_mimic_disguise_from_entity>
  <code>entity::mimic_disguise_from_entity</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Замаскировать сущность под сущность из мира\
**Тип:** Действие без значения\
**Описание:** Маскирует сущность под указанную сущность из мира.

**Пример использования:**
```ts
entity::mimic_disguise_from_entity("name_or_uuid", "TRUE", "TRUE");

//Или в сухую по ключам

entity::mimic_disguise_from_entity(name_or_uuid="name_or_uuid", include_disguise="TRUE", remove_original_entity="TRUE");
```

**Аргументы:**

| ID                     | Тип                                          | Описание                             |
|------------------------|----------------------------------------------|--------------------------------------|
| name_or_uuid           | Текст                                        | Имя или UUID сущности для маскировки |
| include_disguise       | Маркер<br/>**TRUE** - Да<br/>**FALSE** - Нет | Учитывать маскировку сущности        |
| remove_original_entity | Маркер<br/>**TRUE** - Да<br/>**FALSE** - Нет | Удалить настоящую сущность           |

<h3 id=entity_modify_piglin_barter_materials>
  <code>entity::modify_piglin_barter_materials</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Изменить торги пиглина\
**Тип:** Действие без значения\
**Описание:** Изменяет предметы, которые может дать пиглин при обмене.\
**Дополнительная информация:**\
&nbsp;&nbsp;Нельзя изменить предметы, которые пиглин продает по умолчанию.\
**Работает с:**\
&nbsp;&nbsp;Пиглинами

**Пример использования:**
```ts
entity::modify_piglin_barter_materials([item("stick"), item("stick")], "ADD");

//Или в сухую по ключам

entity::modify_piglin_barter_materials(materials=[item("stick"), item("stick")], modification_mode="ADD");
```

**Аргументы:**

| ID                | Тип                                                       | Описание                                                            |
|-------------------|-----------------------------------------------------------|---------------------------------------------------------------------|
| materials         | Список\[Предмет\]                                         | Предметы для изменения<br/>Аргумент поддерживает разложение списков |
| modification_mode | Маркер<br/>**ADD** - Добавление<br/>**REMOVE** - Удаление | Режим изменения                                                     |

<h3 id=entity_modify_piglin_interested_materials>
  <code>entity::modify_piglin_interested_materials</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Изменить предметы для торга с пиглином\
**Тип:** Действие без значения\
**Описание:** Изменяет предметы, требуемые для обмена с пиглином.\
**Дополнительная информация:**\
&nbsp;&nbsp;Нельзя изменить предметы, которые пиглин требует по умолчанию.\
**Работает с:**\
&nbsp;&nbsp;Пиглинами

**Пример использования:**
```ts
entity::modify_piglin_interested_materials([item("stick"), item("stick")], "ADD");

//Или в сухую по ключам

entity::modify_piglin_interested_materials(materials=[item("stick"), item("stick")], modification_mode="ADD");
```

**Аргументы:**

| ID                | Тип                                                       | Описание                                                            |
|-------------------|-----------------------------------------------------------|---------------------------------------------------------------------|
| materials         | Список\[Предмет\]                                         | Предметы для изменения<br/>Аргумент поддерживает разложение списков |
| modification_mode | Маркер<br/>**ADD** - Добавление<br/>**REMOVE** - Удаление | Режим изменения                                                     |

<h3 id=entity_move_to_location>
  <code>entity::move_to_location</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить движение к местоположению\
**Тип:** Действие без значения\
**Описание:** Инструктирует ИИ существа всегда находить путь к определённому местоположению с определённой скоростью.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::move_to_location(location(0,0,0,0,0), 1);

//Или в сухую по ключам

entity::move_to_location(location=location(0,0,0,0,0), speed=1);
```

**Аргументы:**

| ID       | Тип            | Описание                |
|----------|----------------|-------------------------|
| location | Местоположение | Конечное местоположение |
| speed    | Число          | Скорость передвижения   |

<h3 id=entity_move_to_location_stop>
  <code>entity::move_to_location_stop</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Остановить движение к местоположению\
**Тип:** Действие без значения\
**Описание:** Останавливает сущность, идущую к местоположению.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::move_to_location_stop();
```

<h3 id=entity_play_damage_animation>
  <code>entity::play_damage_animation</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Отобразить анимацию урона\
**Тип:** Действие без значения\
**Описание:** Отображает анимацию урона существу.

**Пример использования:**
```ts
entity::play_damage_animation("CRITICAL_DAMAGE");

//Или в сухую по ключам

entity::play_damage_animation(damage_type="CRITICAL_DAMAGE");
```

**Аргументы:**

| ID          | Тип                                                                                                       | Описание  |
|-------------|-----------------------------------------------------------------------------------------------------------|-----------|
| damage_type | Маркер<br/>**CRITICAL_DAMAGE** - Критический<br/>**DAMAGE** - Обычный<br/>**MAGICAL_DAMAGE** - Магический | Тип урона |

<h3 id=entity_play_hurt_animation>
  <code>entity::play_hurt_animation</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Отобразить анимацию получения урона\
**Тип:** Действие без значения\
**Описание:** Отображает существу анимацию получения урона с определённым наклоном.

**Пример использования:**
```ts
entity::play_hurt_animation(1);

//Или в сухую по ключам

entity::play_hurt_animation(yaw=1);
```

**Аргументы:**

| ID  | Тип   | Описание                     |
|-----|-------|------------------------------|
| yaw | Число | Угол получения урона (0-360) |

<h3 id=entity_ram_target>
  <code>entity::ram_target</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Таранить сущность\
**Тип:** Действие без значения\
**Описание:** Заставляет козлов таранить указанную сущность.\
**Работает с:**\
&nbsp;&nbsp;Козлами

**Пример использования:**
```ts
entity::ram_target("name_or_uuid");

//Или в сухую по ключам

entity::ram_target(name_or_uuid="name_or_uuid");
```

**Аргументы:**

| ID           | Тип   | Описание              |
|--------------|-------|-----------------------|
| name_or_uuid | Текст | Имя или UUID сущности |

<h3 id=entity_remove>
  <code>entity::remove</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Удалить сущность\
**Тип:** Действие без значения\
**Описание:** Удаляет сущность из мира.

**Пример использования:**
```ts
entity::remove();
```

<h3 id=entity_remove_custom_tag>
  <code>entity::remove_custom_tag</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Удалить кастомный тег\
**Тип:** Действие без значения\
**Описание:** Удаляет кастомный нбт-тег у существа.

**Пример использования:**
```ts
entity::remove_custom_tag("name");

//Или в сухую по ключам

entity::remove_custom_tag(name="name");
```

**Аргументы:**

| ID   | Тип   | Описание |
|------|-------|----------|
| name | Текст | Имя тега |

<h3 id=entity_remove_disguise>
  <code>entity::remove_disguise</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Убрать маскировку\
**Тип:** Действие без значения\
**Описание:** Убирает маскировку у сущности.

**Пример использования:**
```ts
entity::remove_disguise();
```

<h3 id=entity_remove_merchant_recipe>
  <code>entity::remove_merchant_recipe</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Удалить товар Жителю\
**Тип:** Действие без значения\
**Описание:** Удаляет товар Жителю по указанному индексу.\
**Работает с:**\
&nbsp;&nbsp;Жителями\
&nbsp;&nbsp;Странствующими торговцами

**Пример использования:**
```ts
entity::remove_merchant_recipe(1);

//Или в сухую по ключам

entity::remove_merchant_recipe(recipe_index=1);
```

**Аргументы:**

| ID           | Тип   | Описание      |
|--------------|-------|---------------|
| recipe_index | Число | Индекс товара |

<h3 id=entity_remove_potion_effect>
  <code>entity::remove_potion_effect</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Удалить эффект\
**Тип:** Действие без значения\
**Описание:** Удаляет выбранные эффекты у существа.

**Пример использования:**
```ts
entity::remove_potion_effect([potion("slow_falling"), potion("slow_falling")]);

//Или в сухую по ключам

entity::remove_potion_effect(effects=[potion("slow_falling"), potion("slow_falling")]);
```

**Аргументы:**

| ID      | Тип             | Описание                                                          |
|---------|-----------------|-------------------------------------------------------------------|
| effects | Список\[Зелье\] | Эффекты для удаления<br/>Аргумент поддерживает разложение списков |

<h3 id=entity_reset_display_brightness>
  <code>entity::reset_display_brightness</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сбросить яркость\
**Тип:** Действие без значения\
**Описание:** Сбросить яркость сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::reset_display_brightness();
```

<h3 id=entity_reset_display_glow_color>
  <code>entity::reset_display_glow_color</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сбросить цвет свечения\
**Тип:** Действие без значения\
**Описание:** Сбросить цвет свечения сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами предмета\
&nbsp;&nbsp;Визуализаторами блока

**Пример использования:**
```ts
entity::reset_display_glow_color();
```

<h3 id=entity_reset_mannequin_description>
  <code>entity::reset_mannequin_description</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Очистить описание маникена\
**Тип:** Действие без значения\
**Описание:** Очищает описание маникена.\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::reset_mannequin_description();
```

<h3 id=entity_reset_text_display_background>
  <code>entity::reset_text_display_background</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сбросить цвет фона\
**Тип:** Действие без значения\
**Описание:** Сбросить цвет и прозрачность фона визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::reset_text_display_background();
```

<h3 id=entity_reset_waypoint_color>
  <code>entity::reset_waypoint_color</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сбросить цвет значка на локаторе\
**Тип:** Действие без значения\
**Описание:** Устанавливает сущности цвет значка, отображаемого на локаторе, по умолчанию.\
**Дополнительная информация:**\
&nbsp;&nbsp;Для работы действия, игровое значение "Видимость локатора" должно быть включено.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::reset_waypoint_color();
```

<h3 id=entity_retrieve_fishing_hook>
  <code>entity::retrieve_fishing_hook</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Вернуть поплавок\
**Тип:** Действие без значения\
**Описание:** Возвращает закинутый поплавок удочки, находящейся в указанной руке сущности.\
**Работает с:**\
&nbsp;&nbsp;Удочками

**Пример использования:**
```ts
entity::retrieve_fishing_hook("MAIN_HAND");

//Или в сухую по ключам

entity::retrieve_fishing_hook(slot="MAIN_HAND");
```

**Аргументы:**

| ID   | Тип                                                                             | Описание |
|------|---------------------------------------------------------------------------------|----------|
| slot | Маркер<br/>**MAIN_HAND** - Основная рука<br/>**OFF_HAND** - Второстепенная рука | Тип руки |

<h3 id=entity_ride_entity>
  <code>entity::ride_entity</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Посадить на существо\
**Тип:** Действие без значения\
**Описание:** Сажает существо на другое существо или игрока.

**Пример использования:**
```ts
entity::ride_entity("name_or_uuid");

//Или в сухую по ключам

entity::ride_entity(name_or_uuid="name_or_uuid");
```

**Аргументы:**

| ID           | Тип   | Описание          |
|--------------|-------|-------------------|
| name_or_uuid | Текст | Имя или UUID цели |

<h3 id=entity_roll_armadillo>
  <code>entity::roll_armadillo</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить Броненосцу состояние защиты\
**Тип:** Действие без значения\
**Описание:** Устанавливает броненосцу состояние защиты (свернут ли броненосец).\
**Работает с:**\
&nbsp;&nbsp;Броненосцами

**Пример использования:**
```ts
entity::roll_armadillo("ROLL_OUT");

//Или в сухую по ключам

entity::roll_armadillo(roll="ROLL_OUT");
```

**Аргументы:**

| ID   | Тип                                                               | Описание         |
|------|-------------------------------------------------------------------|------------------|
| roll | Маркер<br/>**ROLL_OUT** - Развернутый<br/>**ROLL_UP** - Свернутый | Состояние защиты |

<h3 id=entity_set_absorption_health>
  <code>entity::set_absorption_health</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить дополнительное здоровье\
**Тип:** Действие без значения\
**Описание:** Устанавливает дополнительное здоровье существа.

**Пример использования:**
```ts
entity::set_absorption_health(1);

//Или в сухую по ключам

entity::set_absorption_health(health=1);
```

**Аргументы:**

| ID     | Тип   | Описание                            |
|--------|-------|-------------------------------------|
| health | Число | Количество дополнительного здоровья |

<h3 id=entity_set_ai>
  <code>entity::set_ai</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить интеллект сущности\
**Тип:** Действие без значения\
**Описание:** Устанавливает интеллект сущности.

**Пример использования:**
```ts
entity::set_ai("FALSE");

//Или в сухую по ключам

entity::set_ai(ai="FALSE");
```

**Аргументы:**

| ID | Тип                                                      | Описание  |
|----|----------------------------------------------------------|-----------|
| ai | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Интеллект |

<h3 id=entity_set_allay_dancing>
  <code>entity::set_allay_dancing</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сделать Тихоню танцующим\
**Тип:** Действие без значения\
**Описание:** Заставляет Тихоню отображать анимацию танца.\
**Работает с:**\
&nbsp;&nbsp;Тихонями

**Пример использования:**
```ts
entity::set_allay_dancing("FALSE");

//Или в сухую по ключам

entity::set_allay_dancing(dance="FALSE");
```

**Аргументы:**

| ID    | Тип                                                      | Описание       |
|-------|----------------------------------------------------------|----------------|
| dance | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Анимация танца |

<h3 id=entity_set_angry>
  <code>entity::set_angry</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим гнева\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу режим гнева на определённую цель.\
**Дополнительная информация:**\
&nbsp;&nbsp;Для корректной работы сущности необходима цель.\
**Работает с:**\
&nbsp;&nbsp;Пчёлами\
&nbsp;&nbsp;Волками\
&nbsp;&nbsp;Зомбифицированными пиглинами\
&nbsp;&nbsp;Эндерменами\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::set_angry("target", "FALSE");

//Или в сухую по ключам

entity::set_angry(target="target", angry="FALSE");
```

**Аргументы:**

| ID     | Тип                                                      | Описание    |
|--------|----------------------------------------------------------|-------------|
| target | Текст                                                    | Имя цели    |
| angry  | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим гнева |

<h3 id=entity_set_animal_age>
  <code>entity::set_animal_age</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить возраст животному\
**Тип:** Действие без значения\
**Описание:** Устанавливает возраст животному.

**Пример использования:**
```ts
entity::set_animal_age(1, "DISABLE");

//Или в сухую по ключам

entity::set_animal_age(age=1, lock="DISABLE");
```

**Аргументы:**

| ID   | Тип                                                                                            | Описание              |
|------|------------------------------------------------------------------------------------------------|-----------------------|
| age  | Число                                                                                          | Возраст               |
| lock | Маркер<br/>**DISABLE** - Выключено<br/>**DONT_CHANGE** - Не заменять<br/>**ENABLE** - Включено | Остановить взросление |

<h3 id=entity_set_armor_items>
  <code>entity::set_armor_items</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить броню\
**Тип:** Действие без значения\
**Описание:** Устанавливает броню сущности.\
**Дополнительная информация:**\
&nbsp;&nbsp;Любой предмет или блок будет отображаться на голове, если положить его в слот шлема.

**Пример использования:**
```ts
entity::set_armor_items(item("stick"), item("stick"), item("stick"), item("stick"));

//Или в сухую по ключам

entity::set_armor_items(helmet=item("stick"), chestplate=item("stick"), leggings=item("stick"), boots=item("stick"));
```

**Аргументы:**

| ID         | Тип     | Описание      |
|------------|---------|---------------|
| helmet     | Предмет | Головной убор |
| chestplate | Предмет | Нагрудник     |
| leggings   | Предмет | Штаны         |
| boots      | Предмет | Ботинки       |

<h3 id=entity_set_armor_stand_parts>
  <code>entity::set_armor_stand_parts</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить детали стойки для брони\
**Тип:** Действие без значения\
**Описание:** Установить детали стойки для брони.\
**Работает с:**\
&nbsp;&nbsp;Стойками для брони

**Пример использования:**
```ts
entity::set_armor_stand_parts("DISABLE", "DISABLE");

//Или в сухую по ключам

entity::set_armor_stand_parts(arms="DISABLE", base_plate="DISABLE");
```

**Аргументы:**

| ID         | Тип                                                                                            | Описание        |
|------------|------------------------------------------------------------------------------------------------|-----------------|
| arms       | Маркер<br/>**DISABLE** - Выключить<br/>**DONT_CHANGE** - Не изменять<br/>**ENABLE** - Включить | Видимость рук   |
| base_plate | Маркер<br/>**DISABLE** - Выключить<br/>**DONT_CHANGE** - Не изменять<br/>**ENABLE** - Включить | Видимость плиты |

<h3 id=entity_set_armor_stand_pose>
  <code>entity::set_armor_stand_pose</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить позу стойки для брони\
**Тип:** Действие без значения\
**Описание:** Устанавливает позу стойки для брони.\
**Работает с:**\
&nbsp;&nbsp;Стойками для брони

**Пример использования:**
```ts
entity::set_armor_stand_pose(1, 2, 3, "BODY");

//Или в сухую по ключам

entity::set_armor_stand_pose(x_rotation=1, y_rotation=2, z_rotation=3, body_part="BODY");
```

**Аргументы:**

| ID         | Тип                                                                                                                                                                          | Описание                   |
|------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------|
| x_rotation | Число                                                                                                                                                                        | Поворот по оси X           |
| y_rotation | Число                                                                                                                                                                        | Поворот по оси Y           |
| z_rotation | Число                                                                                                                                                                        | Поворот по оси Z           |
| body_part  | Маркер<br/>**BODY** - Тело<br/>**HEAD** - Голова<br/>**LEFT_ARM** - Левая рука<br/>**LEFT_LEG** - Левая нога<br/>**RIGHT_ARM** - Правая рука<br/>**RIGHT_LEG** - Правая нога | Часть стойки для изменения |

<h3 id=entity_set_arrow_hit_sound>
  <code>entity::set_arrow_hit_sound</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить звук попадания снаряда\
**Тип:** Действие без значения\
**Описание:** Устанавливает снаряду звук, издаваемый при попадании в сущность.\
**Работает с:**\
&nbsp;&nbsp;Стрелами\
&nbsp;&nbsp;Трезубцами

**Пример использования:**
```ts
entity::set_arrow_hit_sound(sound("entity.zombie.hurt"));

//Или в сухую по ключам

entity::set_arrow_hit_sound(sound=sound("entity.zombie.hurt"));
```

**Аргументы:**

| ID    | Тип  | Описание       |
|-------|------|----------------|
| sound | Звук | Звук попадания |

<h3 id=entity_set_arrow_pierce>
  <code>entity::set_arrow_pierce</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить стреле количество пронзаний\
**Тип:** Действие без значения\
**Описание:** Устанавливает стреле количество раз, которые она может пронзить сущность (от 0 до 127).

**Пример использования:**
```ts
entity::set_arrow_pierce(1);

//Или в сухую по ключам

entity::set_arrow_pierce(pierce=1);
```

**Аргументы:**

| ID     | Тип   | Описание             |
|--------|-------|----------------------|
| pierce | Число | Количество пронзаний |

<h3 id=entity_set_attribute>
  <code>entity::set_attribute</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить атрибут\
**Тип:** Действие без значения\
**Описание:** Устанавливает указанный атрибут на указанное значение существу.

**Пример использования:**
```ts
entity::set_attribute(1, "CAMERA_DISTANCE");

//Или в сухую по ключам

entity::set_attribute(value=1, attribute_type="CAMERA_DISTANCE");
```

**Аргументы:**

| ID             | Тип                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | Описание          |
|----------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|
| value          | Число                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                        | Значение атрибута |
| attribute_type | Маркер<br/>**CAMERA_DISTANCE** - Расстояние камеры при виде от третьего лица<br/>**GENERIC_ARMOR** - Очки защиты (generic.armor)<br/>**GENERIC_ARMOR_TOUGHNESS** - Очки плотности защиты (generic.armor_toughness)<br/>**GENERIC_ATTACK_DAMAGE** - Урон атаки (generic.attack_damage)<br/>**GENERIC_ATTACK_KNOCKBACK** - Отталкивание атаки (generic.attack_knockback)<br/>**GENERIC_ATTACK_SPEED** - Скорость атаки (generic.attack_speed)<br/>**GENERIC_BURNING_TIME** - Время горения<br/>**GENERIC_EXPLOSION_KNOCKBACK_RESISTANCE** - Сопротивление отбрасыванию от взрыва<br/>**GENERIC_FALL_DAMAGE_MULTIPLIER** - Множитель урона от падения<br/>**GENERIC_FLYING_SPEED** - Скорость полёта (generic.flying_speed)<br/>**GENERIC_FOLLOW_RANGE** - Расстояние следования (generic.follow_range)<br/>**GENERIC_GRAVITY** - Гравитация<br/>**GENERIC_JUMP_STRENGTH** - Сила прыжка<br/>**GENERIC_KNOCKBACK_RESISTANCE** - Сопротивление отталкиванию (generic.knockback_resistance)<br/>**GENERIC_LUCK** - Удача рыбалки (generic.luck)<br/>**GENERIC_MAX_ABSORPTION** - Максимальное поглощение (generic.max_absorption)<br/>**GENERIC_MAX_HEALTH** - Максимальное здоровье (generic.max_health)<br/>**GENERIC_MOVEMENT_EFFICIENCY** - Скорость передвижения по замедляющим блокам<br/>**GENERIC_MOVEMENT_SPEED** - Скорость передвижения (generic.movement_speed)<br/>**GENERIC_OXYGEN_BONUS** - Воздух под водой<br/>**GENERIC_SAFE_FALL_DISTANCE** - Безопасная высота падения<br/>**GENERIC_SCALE** - Масштаб<br/>**GENERIC_STEP_HEIGHT** - Высота шага<br/>**GENERIC_WATER_MOVEMENT_EFFICIENCY** - Скорость передвижения под водой<br/>**PLAYER_BLOCK_BREAK_SPEED** - Скорость ломания блока<br/>**PLAYER_BLOCK_INTERACTION_RANGE** - Расстояние взаимодействия с блоками<br/>**PLAYER_ENTITY_INTERACTION_RANGE** - Расстояние взаимодействия с сущностями<br/>**PLAYER_MINING_EFFICIENCY** - Скорость копания<br/>**PLAYER_SNEAKING_SPEED** - Скорость передвижения крадясь<br/>**PLAYER_SUBMERGED_MINING_SPEED** - Скорость копания под водой<br/>**PLAYER_SWEEPING_DAMAGE_RATIO** - Коэффициент разящего удара<br/>**TEMP_RANGE** - Расстояние приманивания<br/>**WAYPOINT_RECEIVE_RANGE** - Расстояние улавливания локатора (waypoint_receive_range)<br/>**WAYPOINT_TRANSMIT_RANGE** - Расстояние улавливания локатором (waypoint_transmit_range)<br/>**ZOMBIE_SPAWN_REINFORCEMENTS** - Шанс подкрепления зомби | Тип атрибута      |

<h3 id=entity_set_aware>
  <code>entity::set_aware</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить осведомлённость моба\
**Тип:** Действие без значения\
**Описание:** В выключенном состоянии отключает ИИ моба, но оставляет взаимодействие с гравитацией, толканием и т.д.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::set_aware("FALSE");

//Или в сухую по ключам

entity::set_aware(aware="FALSE");
```

**Аргументы:**

| ID    | Тип                                                      | Описание        |
|-------|----------------------------------------------------------|-----------------|
| aware | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Осведомлённость |

<h3 id=entity_set_axolotl_type>
  <code>entity::set_axolotl_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип аксолотля\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип аксолотля.\
**Работает с:**\
&nbsp;&nbsp;Аксолотлями

**Пример использования:**
```ts
entity::set_axolotl_type("BLUE");

//Или в сухую по ключам

entity::set_axolotl_type(axolotl_type="BLUE");
```

**Аргументы:**

| ID           | Тип                                                                                                                        | Описание      |
|--------------|----------------------------------------------------------------------------------------------------------------------------|---------------|
| axolotl_type | Маркер<br/>**BLUE** - Синий<br/>**CYAN** - Голубой<br/>**GOLD** - Золотой<br/>**LUCY** - Лейкист<br/>**WILD** - Коричневый | Тип аксолотля |

<h3 id=entity_set_baby>
  <code>entity::set_baby</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим ребёнка\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу режим ребёнка.

**Пример использования:**
```ts
entity::set_baby("FALSE");

//Или в сухую по ключам

entity::set_baby(baby="FALSE");
```

**Аргументы:**

| ID   | Тип                                                      | Описание      |
|------|----------------------------------------------------------|---------------|
| baby | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим ребёнка |

<h3 id=entity_set_base_arrow_damage>
  <code>entity::set_base_arrow_damage</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить первичный урон снаряду\
**Тип:** Действие без значения\
**Описание:** Устанавливает снаряду первичный урон, который будет использован в формуле урона снаряда при попадании.\
**Дополнительная информация:**\
&nbsp;&nbsp;Формула для стрел: первичный_урон * скорость_снаряда = наносимый урон\
&nbsp;&nbsp;Формула для трезубцев: первичный_урон = наносимый урон\
**Работает с:**\
&nbsp;&nbsp;Стрелами\
&nbsp;&nbsp;Трезубцами

**Пример использования:**
```ts
entity::set_base_arrow_damage(1);

//Или в сухую по ключам

entity::set_base_arrow_damage(damage=1);
```

**Аргументы:**

| ID     | Тип   | Описание |
|--------|-------|----------|
| damage | Число | Урон     |

<h3 id=entity_set_bee_has_stinger>
  <code>entity::set_bee_has_stinger</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить Пчеле жало\
**Тип:** Действие без значения\
**Описание:** Устанавливает состояние жала пчеле.\
**Работает с:**\
&nbsp;&nbsp;Пчёлами

**Пример использования:**
```ts
entity::set_bee_has_stinger("TRUE");

//Или в сухую по ключам

entity::set_bee_has_stinger(stinger="TRUE");
```

**Аргументы:**

| ID      | Тип                                            | Описание       |
|---------|------------------------------------------------|----------------|
| stinger | Маркер<br/>**TRUE** - Есть<br/>**FALSE** - Нет | Состояние жала |

<h3 id=entity_set_bee_nectar>
  <code>entity::set_bee_nectar</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить пыльцу пчеле\
**Тип:** Действие без значения\
**Описание:** Устанавливает видимость пыльцы пчеле.\
**Работает с:**\
&nbsp;&nbsp;Пчёлами

**Пример использования:**
```ts
entity::set_bee_nectar("FALSE");

//Или в сухую по ключам

entity::set_bee_nectar(nectar="FALSE");
```

**Аргументы:**

| ID     | Тип                                                      | Описание         |
|--------|----------------------------------------------------------|------------------|
| nectar | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Видимость пыльцы |

<h3 id=entity_set_block_display_block>
  <code>entity::set_block_display_block</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить отображаемый блок\
**Тип:** Действие без значения\
**Описание:** Устанавливает отображаемый блок визуализатору блока.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами блока

**Пример использования:**
```ts
entity::set_block_display_block("minecraft:oak_log[axis=x]");

//Или в сухую по ключам

entity::set_block_display_block(displayed_block="minecraft:oak_log[axis=x]");
```

**Аргументы:**

| ID              | Тип  | Описание          |
|-----------------|------|-------------------|
| displayed_block | Блок | Отображаемый блок |

<h3 id=entity_set_camel_dashing>
  <code>entity::set_camel_dashing</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить анимацию рывка верблюду\
**Тип:** Действие без значения\
**Описание:** Устанавливает анимацию рывка верблюду.\
**Работает с:**\
&nbsp;&nbsp;Верблюдами

**Пример использования:**
```ts
entity::set_camel_dashing("FALSE");

//Или в сухую по ключам

entity::set_camel_dashing(dashing="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание       |
|---------|----------------------------------------------------------|----------------|
| dashing | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Анимация рывка |

<h3 id=entity_set_carrying_chest>
  <code>entity::set_carrying_chest</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить видимость сундука\
**Тип:** Действие без значения\
**Описание:** Устанавливает видимость сундука на сущности.\
**Работает с:**\
&nbsp;&nbsp;Ослами\
&nbsp;&nbsp;Мулами\
&nbsp;&nbsp;Ламами

**Пример использования:**
```ts
entity::set_carrying_chest("FALSE");

//Или в сухую по ключам

entity::set_carrying_chest(carrying="FALSE");
```

**Аргументы:**

| ID       | Тип                                                      | Описание        |
|----------|----------------------------------------------------------|-----------------|
| carrying | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Наличие сундука |

<h3 id=entity_set_cat_lying_down>
  <code>entity::set_cat_lying_down</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим лежания кошке\
**Тип:** Действие без значения\
**Описание:** Устанавливает режим лежания кошке.\
**Работает с:**\
&nbsp;&nbsp;Кошками

**Пример использования:**
```ts
entity::set_cat_lying_down("FALSE");

//Или в сухую по ключам

entity::set_cat_lying_down(lying_down="FALSE");
```

**Аргументы:**

| ID         | Тип                                                      | Описание      |
|------------|----------------------------------------------------------|---------------|
| lying_down | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим лежания |

<h3 id=entity_set_cat_type>
  <code>entity::set_cat_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип кошки\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип кошки.\
**Работает с:**\
&nbsp;&nbsp;Кошками

**Пример использования:**
```ts
entity::set_cat_type("ALL_BLACK");

//Или в сухую по ключам

entity::set_cat_type(cat_type="ALL_BLACK");
```

**Аргументы:**

| ID       | Тип                                                                                                                                                                                                                                                                                                                                | Описание  |
|----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------|
| cat_type | Маркер<br/>**ALL_BLACK** - Чёрная<br/>**BLACK** - Чёрно-белая<br/>**BRITISH_SHORTHAIR** - Британская короткошёрстная<br/>**CALICO** - Ситцевая<br/>**JELLIE** - Бело-серая<br/>**PERSIAN** - Персидская<br/>**RAGDOLL** - Тряпичная<br/>**RED** - Рыжая<br/>**SIAMESE** - Сиамская<br/>**TABBY** - Полосатая<br/>**WHITE** - Белая | Тип кошки |

<h3 id=entity_set_celebrating>
  <code>entity::set_celebrating</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим празднования\
**Тип:** Действие без значения\
**Описание:** Устанавливает режим празднования существу.\
**Работает с:**\
&nbsp;&nbsp;Пиглинами\
&nbsp;&nbsp;Рейдерами

**Пример использования:**
```ts
entity::set_celebrating("FALSE");

//Или в сухую по ключам

entity::set_celebrating(celebrating="FALSE");
```

**Аргументы:**

| ID          | Тип                                                      | Описание           |
|-------------|----------------------------------------------------------|--------------------|
| celebrating | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим празднования |

<h3 id=entity_set_chicken_type>
  <code>entity::set_chicken_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип Курицы\
**Тип:** Действие без значения\
**Описание:** Устанавливает курице тип окраски.\
**Работает с:**\
&nbsp;&nbsp;Курицами

**Пример использования:**
```ts
entity::set_chicken_type("COLD");

//Или в сухую по ключам

entity::set_chicken_type(variant="COLD");
```

**Аргументы:**

| ID      | Тип                                                                                  | Описание    |
|---------|--------------------------------------------------------------------------------------|-------------|
| variant | Маркер<br/>**COLD** - Снежная<br/>**WARM** - Тропическая<br/>**TEMPERATE** - Обычная | Тип окраски |

<h3 id=entity_set_collidable>
  <code>entity::set_collidable</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим столкновения\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу режим столкновения с другими существами.

**Пример использования:**
```ts
entity::set_collidable("FALSE");

//Или в сухую по ключам

entity::set_collidable(collidable="FALSE");
```

**Аргументы:**

| ID         | Тип                                                                                                          | Описание           |
|------------|--------------------------------------------------------------------------------------------------------------|--------------------|
| collidable | Маркер<br/>**FALSE** - Не сталкивается с другими существами<br/>**TRUE** - Сталкивается с другими существами | Режим столкновения |

<h3 id=entity_set_copper_golem_oxidizing>
  <code>entity::set_copper_golem_oxidizing</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить вощённость медного голема\
**Тип:** Действие без значения\
**Описание:** Устанавливает вощённость медного голема.\
**Работает с:**\
&nbsp;&nbsp;Медными големами

**Пример использования:**
```ts
entity::set_copper_golem_oxidizing("WAXED");

//Или в сухую по ключам

entity::set_copper_golem_oxidizing(oxidizing_state="WAXED");
```

**Аргументы:**

| ID              | Тип                                           | Описание   |
|-----------------|-----------------------------------------------|------------|
| oxidizing_state | Маркер<br/>**WAXED** - Да<br/>**UNSET** - Нет | Вощённость |

<h3 id=entity_set_copper_golem_oxidizing_at_time>
  <code>entity::set_copper_golem_oxidizing_at_time</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить время окисления медного голема\
**Тип:** Действие без значения\
**Описание:** Устанавливает время, за которое медный голем повышает уровень окисления под дождём.\
**Работает с:**\
&nbsp;&nbsp;Медными големами

**Пример использования:**
```ts
entity::set_copper_golem_oxidizing_at_time(1);

//Или в сухую по ключам

entity::set_copper_golem_oxidizing_at_time(time=1);
```

**Аргументы:**

| ID   | Тип   | Описание         |
|------|-------|------------------|
| time | Число | Количество тиков |

<h3 id=entity_set_copper_golem_weathering>
  <code>entity::set_copper_golem_weathering</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить окисление медного голема\
**Тип:** Действие без значения\
**Описание:** Устанавливает степень окисления медного голема.\
**Работает с:**\
&nbsp;&nbsp;Медными големами

**Пример использования:**
```ts
entity::set_copper_golem_weathering(1);

//Или в сухую по ключам

entity::set_copper_golem_weathering(weathering_state=1);
```

**Аргументы:**

| ID               | Тип   | Описание          |
|------------------|-------|-------------------|
| weathering_state | Число | Степень окисления |

<h3 id=entity_set_cow_type>
  <code>entity::set_cow_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип Коровы\
**Тип:** Действие без значения\
**Описание:** Устанавливает корове тип окраски.\
**Работает с:**\
&nbsp;&nbsp;Коровами

**Пример использования:**
```ts
entity::set_cow_type("COLD");

//Или в сухую по ключам

entity::set_cow_type(variant="COLD");
```

**Аргументы:**

| ID      | Тип                                                                                  | Описание    |
|---------|--------------------------------------------------------------------------------------|-------------|
| variant | Маркер<br/>**COLD** - Снежная<br/>**WARM** - Тропическая<br/>**TEMPERATE** - Обычная | Тип окраски |

<h3 id=entity_set_creeper_charge>
  <code>entity::set_creeper_charge</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить заряженность криперу\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли крипер заряженным.\
**Работает с:**\
&nbsp;&nbsp;Криперами

**Пример использования:**
```ts
entity::set_creeper_charge("FALSE");

//Или в сухую по ключам

entity::set_creeper_charge(charged="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание             |
|---------|----------------------------------------------------------|----------------------|
| charged | Маркер<br/>**FALSE** - Не заряжен<br/>**TRUE** - Заряжен | Заряженность крипера |

<h3 id=entity_set_creeper_fuse>
  <code>entity::set_creeper_fuse</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить максимальное время взрыва криперу\
**Тип:** Действие без значения\
**Описание:** Устанавливает максимальное время взрыва криперу.\
**Работает с:**\
&nbsp;&nbsp;Криперами

**Пример использования:**
```ts
entity::set_creeper_fuse(1);

//Или в сухую по ключам

entity::set_creeper_fuse(fuse_ticks=1);
```

**Аргументы:**

| ID         | Тип   | Описание                  |
|------------|-------|---------------------------|
| fuse_ticks | Число | Время до взрыва (в тиках) |

<h3 id=entity_set_current_health>
  <code>entity::set_current_health</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить здоровье существа\
**Тип:** Действие без значения\
**Описание:** Устанавливает здоровье существа на выбранное количество.

**Пример использования:**
```ts
entity::set_current_health(1);

//Или в сухую по ключам

entity::set_current_health(health=1);
```

**Аргументы:**

| ID     | Тип   | Описание            |
|--------|-------|---------------------|
| health | Число | Количество здоровья |

<h3 id=entity_set_custom_name>
  <code>entity::set_custom_name</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить имя\
**Тип:** Действие без значения\
**Описание:** Устанавливает имя для существа.

**Пример использования:**
```ts
entity::set_custom_name("custom_name");

//Или в сухую по ключам

entity::set_custom_name(custom_name="custom_name");
```

**Аргументы:**

| ID          | Тип   | Описание     |
|-------------|-------|--------------|
| custom_name | Текст | Имя существа |

<h3 id=entity_set_custom_name_visibility>
  <code>entity::set_custom_name_visibility</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить видимость имени\
**Тип:** Действие без значения\
**Описание:** Устанавливает видимость имени существа.

**Пример использования:**
```ts
entity::set_custom_name_visibility("FALSE");

//Или в сухую по ключам

entity::set_custom_name_visibility(visibility="FALSE");
```

**Аргументы:**

| ID         | Тип                                                      | Описание        |
|------------|----------------------------------------------------------|-----------------|
| visibility | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Видимость имени |

<h3 id=entity_set_custom_tag>
  <code>entity::set_custom_tag</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить кастомный тег\
**Тип:** Действие без значения\
**Описание:** Устанавливает кастомный нбт-тег существу.

**Пример использования:**
```ts
entity::set_custom_tag("name", "value");

//Или в сухую по ключам

entity::set_custom_tag(name="name", value="value");
```

**Аргументы:**

| ID    | Тип   | Описание      |
|-------|-------|---------------|
| name  | Текст | Имя тега      |
| value | Текст | Значение тега |

<h3 id=entity_set_death_drops>
  <code>entity::set_death_drops</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить выпадение предметов\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли выпадать лут с существа.

**Пример использования:**
```ts
entity::set_death_drops("FALSE");

//Или в сухую по ключам

entity::set_death_drops(drops="FALSE");
```

**Аргументы:**

| ID    | Тип                                                      | Описание            |
|-------|----------------------------------------------------------|---------------------|
| drops | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Выпадение предметов |

<h3 id=entity_set_death_time>
  <code>entity::set_death_time</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить длительность смерти\
**Тип:** Действие без значения\
**Описание:** Устанавливает длительность смерти для существа.

**Пример использования:**
```ts
entity::set_death_time(1);

//Или в сухую по ключам

entity::set_death_time(death_time=1);
```

**Аргументы:**

| ID         | Тип   | Описание                      |
|------------|-------|-------------------------------|
| death_time | Число | Длительность смерти (в тиках) |

<h3 id=entity_set_default_visible>
  <code>entity::set_default_visible</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить видимость\
**Тип:** Действие без значения\
**Описание:** Устанавливает сущности видимость.\
**Дополнительная информация:**\
&nbsp;&nbsp;Видимость сущности может быть изменена через действие "Скрыть сущность игроку".

**Пример использования:**
```ts
entity::set_default_visible("TRUE");

//Или в сухую по ключам

entity::set_default_visible(default_visible="TRUE");
```

**Аргументы:**

| ID              | Тип                                                     | Описание  |
|-----------------|---------------------------------------------------------|-----------|
| default_visible | Маркер<br/>**TRUE** - Видимый<br/>**FALSE** - Невидимый | Видимость |

<h3 id=entity_set_despawning>
  <code>entity::set_despawning</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить пропадание существа\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли пропадать существо.

**Пример использования:**
```ts
entity::set_despawning("FALSE");

//Или в сухую по ключам

entity::set_despawning(despawning="FALSE");
```

**Аргументы:**

| ID         | Тип                                                      | Описание            |
|------------|----------------------------------------------------------|---------------------|
| despawning | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Пропадание существа |

<h3 id=entity_set_display_billboard>
  <code>entity::set_display_billboard</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим отображения\
**Тип:** Действие без значения\
**Описание:** Устанавливает режим отображения сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_billboard("CENTER");

//Или в сухую по ключам

entity::set_display_billboard(billboard_type="CENTER");
```

**Аргументы:**

| ID             | Тип                                                                                                                                                                            | Описание          |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|
| billboard_type | Маркер<br/>**CENTER** - Всегда повёрнут к игроку<br/>**FIXED** - Фиксированный<br/>**HORIZONTAL** - Фиксированный по горизонтали<br/>**VERTICAL** - Фиксированный по вертикали | Режим отображения |

<h3 id=entity_set_display_brightness>
  <code>entity::set_display_brightness</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить яркость\
**Тип:** Действие без значения\
**Описание:** Устанавливает яркость сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_brightness(1, 2);

//Или в сухую по ключам

entity::set_display_brightness(block_light_level=1, sky_light_level=2);
```

**Аргументы:**

| ID                | Тип   | Описание                |
|-------------------|-------|-------------------------|
| block_light_level | Число | Уровень света от блоков |
| sky_light_level   | Число | Уровень света от неба   |

<h3 id=entity_set_display_correct_transformation_matrix>
  <code>entity::set_display_correct_transformation_matrix</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить матрицу преобразования\
**Тип:** Действие без значения\
**Описание:** Устанавливает матрицу преобразования сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_correct_transformation_matrix([1, 2]);

//Или в сухую по ключам

entity::set_display_correct_transformation_matrix(matrix=[1, 2]);
```

**Аргументы:**

| ID     | Тип             | Описание                                                         |
|--------|-----------------|------------------------------------------------------------------|
| matrix | Список\[Число\] | Матрица из 16 чисел<br/>Аргумент поддерживает разложение списков |

<h3 id=entity_set_display_culling_suze>
  <code>entity::set_display_culling_size</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить размер области видимости\
**Тип:** Действие без значения\
**Описание:** Устанавливает размер области видимости модели сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_culling_size(1, 2);

//Или в сухую по ключам

entity::set_display_culling_size(width=1, height=2);
```

**Аргументы:**

| ID     | Тип   | Описание              |
|--------|-------|-----------------------|
| width  | Число | Горизонтальный размер |
| height | Число | Вертикальный размер   |

<h3 id=entity_set_display_glow_color>
  <code>entity::set_display_glow_color</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цвет свечения\
**Тип:** Действие без значения\
**Описание:** Устанавливает цвет свечения сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами предмета\
&nbsp;&nbsp;Визуализаторами блока

**Пример использования:**
```ts
entity::set_display_glow_color("color_hexadecimal");

//Или в сухую по ключам

entity::set_display_glow_color(color_hexadecimal="color_hexadecimal");
```

**Аргументы:**

| ID                | Тип   | Описание |
|-------------------|-------|----------|
| color_hexadecimal | Текст | HEX цвет |

<h3 id=entity_set_display_interpolation>
  <code>entity::set_display_interpolation</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить интерполяцию\
**Тип:** Действие без значения\
**Описание:** Устанавливает длительность интерполяции сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_interpolation(1, 2);

//Или в сухую по ключам

entity::set_display_interpolation(interpolation_duration=1, interpolation_delay=2);
```

**Аргументы:**

| ID                     | Тип   | Описание                     |
|------------------------|-------|------------------------------|
| interpolation_duration | Число | Длительность интерполяции    |
| interpolation_delay    | Число | Задержка перед интерполяцией |

<h3 id=entity_set_display_rotation_from_axis_angle>
  <code>entity::set_display_rotation_from_axis_angle</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить поворот по осевому вектору\
**Тип:** Действие без значения\
**Описание:** Устанавливает левый или правый поворот по осевому вектору и углу сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_rotation_from_axis_angle(vector(0,0,0), 1, "ADD", "DEGREES", "LEFT_ROTATION");

//Или в сухую по ключам

entity::set_display_rotation_from_axis_angle(axis_vector=vector(0,0,0), angle=1, mode="ADD", input="DEGREES", rotation="LEFT_ROTATION");
```

**Аргументы:**

| ID          | Тип                                                                                                                        | Описание                    |
|-------------|----------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| axis_vector | Вектор                                                                                                                     | Осевой вектор               |
| angle       | Число                                                                                                                      | Угол поворота               |
| mode        | Маркер<br/>**ADD** - Добавление<br/>**SET** - Установка                                                                    | Режим установки             |
| input       | Маркер<br/>**DEGREES** - Градусы<br/>**RADIANS** - Радианы                                                                 | Тип угла                    |
| rotation    | Маркер<br/>**LEFT_ROTATION** - Левый поворот (Поворот х Размер)<br/>**RIGHT_ROTATION** - Правый поворот (Размер х Поворот) | Порядок применения поворота |

<h3 id=entity_set_display_rotation_from_euler_angles>
  <code>entity::set_display_rotation_from_euler_angles</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить поворот по углам Эйлера\
**Тип:** Действие без значения\
**Описание:** Устанавливает левый или правый поворот по углам Эйлера сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_rotation_from_euler_angles(1, 2, 3, "ADD", "DEGREES", "LEFT_ROTATION");

//Или в сухую по ключам

entity::set_display_rotation_from_euler_angles(pitch=1, yaw=2, roll=3, mode="ADD", input="DEGREES", rotation="LEFT_ROTATION");
```

**Аргументы:**

| ID       | Тип                                                                                                                        | Описание                    |
|----------|----------------------------------------------------------------------------------------------------------------------------|-----------------------------|
| pitch    | Число                                                                                                                      | Угол тангажа (pitch)        |
| yaw      | Число                                                                                                                      | Угол рыскания (yaw)         |
| roll     | Число                                                                                                                      | Угол крена (roll)           |
| mode     | Маркер<br/>**ADD** - Добавление<br/>**SET** - Установка                                                                    | Режим установки             |
| input    | Маркер<br/>**DEGREES** - Градусы<br/>**RADIANS** - Радианы                                                                 | Тип угла                    |
| rotation | Маркер<br/>**LEFT_ROTATION** - Левый поворот (Поворот х Размер)<br/>**RIGHT_ROTATION** - Правый поворот (Размер х Поворот) | Порядок применения поворота |

<h3 id=entity_set_display_scale>
  <code>entity::set_display_scale</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить размер\
**Тип:** Действие без значения\
**Описание:** Устанавливает размер сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_scale(vector(0,0,0), "ADD");

//Или в сухую по ключам

entity::set_display_scale(scale_vector=vector(0,0,0), mode="ADD");
```

**Аргументы:**

| ID           | Тип                                                     | Описание        |
|--------------|---------------------------------------------------------|-----------------|
| scale_vector | Вектор                                                  | Новый размер    |
| mode         | Маркер<br/>**ADD** - Добавление<br/>**SET** - Установка | Режим установки |

<h3 id=entity_set_display_shadow>
  <code>entity::set_display_shadow</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить настройки тени\
**Тип:** Действие без значения\
**Описание:** Устанавливает размер и прозрачность тени сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_shadow(1, 2);

//Или в сухую по ключам

entity::set_display_shadow(shadow_radius=1, shadow_opacity_percentage=2);
```

**Аргументы:**

| ID                        | Тип   | Описание               |
|---------------------------|-------|------------------------|
| shadow_radius             | Число | Радиус тени            |
| shadow_opacity_percentage | Число | Процент непрозрачности |

<h3 id=entity_set_display_teleport_duration>
  <code>entity::set_display_teleport_duration</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить длительность телепорта визуализатора\
**Тип:** Действие без значения\
**Описание:** Устанавливает длительность телепорта визуализатора.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_teleport_duration(1);

//Или в сухую по ключам

entity::set_display_teleport_duration(duration=1);
```

**Аргументы:**

| ID       | Тип   | Описание               |
|----------|-------|------------------------|
| duration | Число | Длительность телепорта |

<h3 id=entity_set_display_transformation_matrix>
  <code>entity::set_display_transformation_matrix</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить матрицу преобразования\
**Тип:** Действие без значения\
**Описание:** Устанавливает матрицу преобразования (ряд-столбец) сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

В настоящий момент скрыто. Скорее всего, либо устарело, либо не работает.

**Пример использования:**
```ts
entity::set_display_transformation_matrix([1, 2]);

//Или в сухую по ключам

entity::set_display_transformation_matrix(row_major_matrix=[1, 2]);
```

**Аргументы:**

| ID               | Тип             | Описание                                                         |
|------------------|-----------------|------------------------------------------------------------------|
| row_major_matrix | Список\[Число\] | Матрица из 16 чисел<br/>Аргумент поддерживает разложение списков |

<h3 id=entity_set_display_translation>
  <code>entity::set_display_translation</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить смещение\
**Тип:** Действие без значения\
**Описание:** Устанавливает смещение сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_translation(vector(0,0,0), "ADD");

//Или в сухую по ключам

entity::set_display_translation(translation_vector=vector(0,0,0), mode="ADD");
```

**Аргументы:**

| ID                 | Тип                                                     | Описание        |
|--------------------|---------------------------------------------------------|-----------------|
| translation_vector | Вектор                                                  | Новое смещение  |
| mode               | Маркер<br/>**ADD** - Добавление<br/>**SET** - Установка | Режим установки |

<h3 id=entity_set_display_view_range>
  <code>entity::set_display_view_range</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить дальность видимости\
**Тип:** Действие без значения\
**Описание:** Устанавливает дальность видимости сущности-визуализатору.\
**Работает с:**\
&nbsp;&nbsp;Любой сущностью-визуализатором

**Пример использования:**
```ts
entity::set_display_view_range(1);

//Или в сухую по ключам

entity::set_display_view_range(view_range=1);
```

**Аргументы:**

| ID         | Тип   | Описание            |
|------------|-------|---------------------|
| view_range | Число | Дальность видимости |

<h3 id=entity_set_dragon_phase>
  <code>entity::set_dragon_phase</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить фазу Эндер-дракона\
**Тип:** Действие без значения\
**Описание:** Устанавливает определённую фазу Эндер-дракону.\
**Работает с:**\
&nbsp;&nbsp;Эндер-драконами

**Пример использования:**
```ts
entity::set_dragon_phase("BREATH_ATTACK");

//Или в сухую по ключам

entity::set_dragon_phase(phase="BREATH_ATTACK");
```

**Аргументы:**

| ID    | Тип                                                                                                                                                                                                                                                                                                                                                                                                                                             | Описание           |
|-------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------|
| phase | Маркер<br/>**BREATH_ATTACK** - Атака дыханием<br/>**CHARGE_PLAYER** - Атака на игрока<br/>**CIRCLING** - Кружение<br/>**DYING** - Смерть<br/>**FLY_TO_PORTAL** - Полёт к порталу<br/>**HOVER** - Полёт<br/>**LAND_ON_PORTAL** - Приземление на портал<br/>**LEAVE_PORTAL** - Покидание портала<br/>**ROAR_BEFORE_ATTACK** - Крик перед атакой<br/>**SEARCH_FOR_BREATH_ATTACK_TARGET** - Поиск цели для атаки дыханием<br/>**STRAFING** - Уворот | Фаза Эндер-дракона |

<h3 id=entity_set_dye_color>
  <code>entity::set_dye_color</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цвет сущности\
**Тип:** Действие без значения\
**Описание:** Устанавливает определённый цвет существу.\
**Работает с:**\
&nbsp;&nbsp;Овцами\
&nbsp;&nbsp;Шалкерами\
&nbsp;&nbsp;Ошейниками собак\
&nbsp;&nbsp;Ошейниками котов

**Пример использования:**
```ts
entity::set_dye_color("BLACK");

//Или в сухую по ключам

entity::set_dye_color(color="BLACK");
```

**Аргументы:**

| ID    | Тип                                                                                                                                                                                                                                                                                                                                                                                                                      | Описание      |
|-------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------|
| color | Маркер<br/>**BLACK** - Чёрный<br/>**BLUE** - Синий<br/>**BROWN** - Коричневый<br/>**CYAN** - Бирюзовый<br/>**GRAY** - Серый<br/>**GREEN** - Зелёный<br/>**LIGHT_BLUE** - Голубой<br/>**LIGHT_GRAY** - Светло-серый<br/>**LIME** - Лаймовый<br/>**MAGENTA** - Пурпурный<br/>**ORANGE** - Оранжевый<br/>**PINK** - Розовый<br/>**PURPLE** - Фиолетовый<br/>**RED** - Красный<br/>**WHITE** - Белый<br/>**YELLOW** - Жёлтый | Цвет сущности |

<h3 id=entity_set_end_crystal_beam>
  <code>entity::set_end_crystal_beam</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Указать луч кристалла Энда\
**Тип:** Действие без значения\
**Описание:** Указывает луч кристалла Энда на определённое местоположение.\
**Работает с:**\
&nbsp;&nbsp;Кристаллами Энда

**Пример использования:**
```ts
entity::set_end_crystal_beam(location(0,0,0,0,0));

//Или в сухую по ключам

entity::set_end_crystal_beam(beam=location(0,0,0,0,0));
```

**Аргументы:**

| ID   | Тип            | Описание                    |
|------|----------------|-----------------------------|
| beam | Местоположение | Местоположение для указания |

<h3 id=entity_set_enderman_block>
  <code>entity::set_enderman_block</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить блок Эндермену\
**Тип:** Действие без значения\
**Описание:** Устанавливает отображаемый блок Эндермену.\
**Работает с:**\
&nbsp;&nbsp;Эндерменами

**Пример использования:**
```ts
entity::set_enderman_block("minecraft:oak_log[axis=x]");

//Или в сухую по ключам

entity::set_enderman_block(block="minecraft:oak_log[axis=x]");
```

**Аргументы:**

| ID    | Тип  | Описание          |
|-------|------|-------------------|
| block | Блок | Отображаемый блок |

<h3 id=entity_set_equipment_item>
  <code>entity::set_equipment_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить экипировку\
**Тип:** Действие без значения\
**Описание:** Устанавливает предметы в один из слотов экипировки (броня и предметы в руках) сущности.

**Пример использования:**
```ts
entity::set_equipment_item(item("stick"), "BODY");

//Или в сухую по ключам

entity::set_equipment_item(item=item("stick"), slot="BODY");
```

**Аргументы:**

| ID   | Тип                                                                                                                                                                                       | Описание            |
|------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------|
| item | Предмет                                                                                                                                                                                   | Предметы для выдачи |
| slot | Маркер<br/>**BODY** - Тело<br/>**CHEST** - Нагрудник<br/>**FEET** - Ботинки<br/>**HAND** - Основная рука<br/>**HEAD** - Шлем<br/>**LEGS** - Поножи<br/>**OFF_HAND** - Второстепенная рука | Слот снаряжения     |

<h3 id=entity_set_explosive_power>
  <code>entity::set_explosive_power</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить силу взрыва\
**Тип:** Действие без значения\
**Описание:** Устанавливает силу взрыва сущности.\
**Работает с:**\
&nbsp;&nbsp;Криперами\
&nbsp;&nbsp;Динамитом\
&nbsp;&nbsp;Огненными шарами

**Пример использования:**
```ts
entity::set_explosive_power(1);

//Или в сухую по ключам

entity::set_explosive_power(power=1);
```

**Аргументы:**

| ID    | Тип   | Описание    |
|-------|-------|-------------|
| power | Число | Сила взрыва |

<h3 id=entity_set_fall_distance>
  <code>entity::set_fall_distance</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить дистанцию падения\
**Тип:** Действие без значения\
**Описание:** Устанавливает дистанцию, с которой падает существо.

**Пример использования:**
```ts
entity::set_fall_distance(1);

//Или в сухую по ключам

entity::set_fall_distance(fall_distance=1);
```

**Аргументы:**

| ID            | Тип   | Описание          |
|---------------|-------|-------------------|
| fall_distance | Число | Дистанция падения |

<h3 id=entity_set_falling_block_type>
  <code>entity::set_falling_block_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип существу Падающий блок\
**Тип:** Действие без значения\
**Описание:** Устанавливает новый тип блока существу Падающий блок.\
**Работает с:**\
&nbsp;&nbsp;Падающими блоками

**Пример использования:**
```ts
entity::set_falling_block_type("minecraft:oak_log[axis=x]");

//Или в сухую по ключам

entity::set_falling_block_type(block="minecraft:oak_log[axis=x]");
```

**Аргументы:**

| ID    | Тип  | Описание   |
|-------|------|------------|
| block | Блок | Новый блок |

<h3 id=entity_set_fire_ticks>
  <code>entity::set_fire_ticks</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Поджечь существо\
**Тип:** Действие без значения\
**Описание:** Поджигает существо на выбранное время.

**Пример использования:**
```ts
entity::set_fire_ticks(1);

//Или в сухую по ключам

entity::set_fire_ticks(ticks=1);
```

**Аргументы:**

| ID    | Тип   | Описание               |
|-------|-------|------------------------|
| ticks | Число | Длительность (в тиках) |

<h3 id=entity_set_fishing_wait>
  <code>entity::set_fishing_wait</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить задержку рыбалки\
**Тип:** Действие без значения\
**Описание:** Устанавливает задержку рыбалки существу в тиках.\
**Работает с:**\
&nbsp;&nbsp;Поплавком удочки

**Пример использования:**
```ts
entity::set_fishing_wait(1, "MAX_WAIT");

//Или в сухую по ключам

entity::set_fishing_wait(time=1, wait_type="MAX_WAIT");
```

**Аргументы:**

| ID        | Тип                                                                                                                                                                                | Описание     |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|
| time      | Число                                                                                                                                                                              | Задержка     |
| wait_type | Маркер<br/>**MAX_WAIT** - Максимальная задержка<br/>**MIN_MAX_WAIT** - Минимальная и максимальная задержка<br/>**MIN_WAIT** - Минимальная задержка<br/>**WAIT** - Текущая задержка | Тип задержки |

<h3 id=entity_set_fox_leaping>
  <code>entity::set_fox_leaping</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить анимацию прыжка лисе\
**Тип:** Действие без значения\
**Описание:** Устанавливает анимацию прыжка лисе.\
**Работает с:**\
&nbsp;&nbsp;Лисами

**Пример использования:**
```ts
entity::set_fox_leaping("FALSE");

//Или в сухую по ключам

entity::set_fox_leaping(leaping="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание        |
|---------|----------------------------------------------------------|-----------------|
| leaping | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Анимация прыжка |

<h3 id=entity_set_fox_type>
  <code>entity::set_fox_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип лисы\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип лисы.\
**Работает с:**\
&nbsp;&nbsp;Лисами

**Пример использования:**
```ts
entity::set_fox_type("RED");

//Или в сухую по ключам

entity::set_fox_type(fox_type="RED");
```

**Аргументы:**

| ID       | Тип                                                    | Описание |
|----------|--------------------------------------------------------|----------|
| fox_type | Маркер<br/>**RED** - Стандартный<br/>**SNOW** - Зимний | Тип лисы |

<h3 id=entity_set_freeze_ticks>
  <code>entity::set_freeze_ticks</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить время заморозки\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу время заморозки (количество тиков, которое сущность провела в рыхлом снегу).

**Пример использования:**
```ts
entity::set_freeze_ticks(1, "FALSE");

//Или в сухую по ключам

entity::set_freeze_ticks(ticks=1, ticking_locked="FALSE");
```

**Аргументы:**

| ID             | Тип                                                      | Описание                                         |
|----------------|----------------------------------------------------------|--------------------------------------------------|
| ticks          | Число                                                    | Время заморозки в тиках                          |
| ticking_locked | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Блокировка состояния (время не будет изменяться) |

<h3 id=entity_set_friction>
  <code>entity::set_friction</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить трение\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли сущность испытывать трение.

**Пример использования:**
```ts
entity::set_friction("NOT_SET");

//Или в сухую по ключам

entity::set_friction(friction="NOT_SET");
```

**Аргументы:**

| ID       | Тип                                                                         | Описание          |
|----------|-----------------------------------------------------------------------------|-------------------|
| friction | Маркер<br/>**NOT_SET** - По умолчанию<br/>**TRUE** - Да<br/>**FALSE** - Нет | Испытывать трение |

<h3 id=entity_set_frog_type>
  <code>entity::set_frog_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип жабы\
**Тип:** Действие без значения\
**Описание:** Устанавливает окрас жабы.\
**Работает с:**\
&nbsp;&nbsp;Жабами

**Пример использования:**
```ts
entity::set_frog_type("COLD");

//Или в сухую по ключам

entity::set_frog_type(frog_variant="COLD");
```

**Аргументы:**

| ID           | Тип                                                                                | Описание |
|--------------|------------------------------------------------------------------------------------|----------|
| frog_variant | Маркер<br/>**COLD** - Холодный<br/>**TEMPERATE** - Умеренный<br/>**WARM** - Тёплый | Тип жабы |

<h3 id=entity_set_fuse_ticks>
  <code>entity::set_fuse_ticks</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить время до взрыва\
**Тип:** Действие без значения\
**Описание:** Устанавливает время до взрыва сущности.\
**Работает с:**\
&nbsp;&nbsp;Криперами\
&nbsp;&nbsp;Динамитом\
&nbsp;&nbsp;Фейерверками

**Пример использования:**
```ts
entity::set_fuse_ticks(1);

//Или в сухую по ключам

entity::set_fuse_ticks(fuse_ticks=1);
```

**Аргументы:**

| ID         | Тип   | Описание                  |
|------------|-------|---------------------------|
| fuse_ticks | Число | Время до взрыва (в тиках) |

<h3 id=entity_set_gliding>
  <code>entity::set_gliding</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить полёт на элитрах\
**Тип:** Действие без значения\
**Описание:** Устанавливает для существа состояние полёта на элитрах.

**Пример использования:**
```ts
entity::set_gliding("FALSE");

//Или в сухую по ключам

entity::set_gliding(is_gliding="FALSE");
```

**Аргументы:**

| ID         | Тип                                                      | Описание         |
|------------|----------------------------------------------------------|------------------|
| is_gliding | Маркер<br/>**FALSE** - Выключено<br/>**TRUE** - Включено | Полёт на элитрах |

<h3 id=entity_set_glow_squid_dark>
  <code>entity::set_glow_squid_dark</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить время тьмы спруту\
**Тип:** Действие без значения\
**Описание:** Устанавливает время тьмы в тиках светящемуся спруту.\
**Работает с:**\
&nbsp;&nbsp;Светящимся спрутами

**Пример использования:**
```ts
entity::set_glow_squid_dark(1);

//Или в сухую по ключам

entity::set_glow_squid_dark(dark_ticks=1);
```

**Аргументы:**

| ID         | Тип   | Описание             |
|------------|-------|----------------------|
| dark_ticks | Число | Время тьмы (в тиках) |

<h3 id=entity_set_glowing>
  <code>entity::set_glowing</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить свечение сущности\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу эффект свечения.

**Пример использования:**
```ts
entity::set_glowing("FALSE");

//Или в сухую по ключам

entity::set_glowing(glowing="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание |
|---------|----------------------------------------------------------|----------|
| glowing | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Свечение |

<h3 id=entity_set_goat_screaming>
  <code>entity::set_goat_screaming</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить козла кричащим\
**Тип:** Действие без значения\
**Описание:** Устанавливает тег "кричащий" козлу.\
**Работает с:**\
&nbsp;&nbsp;Козлами

**Пример использования:**
```ts
entity::set_goat_screaming("FALSE");

//Или в сухую по ключам

entity::set_goat_screaming(screams="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание       |
|---------|----------------------------------------------------------|----------------|
| screams | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Тег "Кричащий" |

<h3 id=entity_set_gravity>
  <code>entity::set_gravity</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить гравитацию\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли сущность подчиняться гравитации.

**Пример использования:**
```ts
entity::set_gravity("FALSE");

//Или в сухую по ключам

entity::set_gravity(gravity="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание   |
|---------|----------------------------------------------------------|------------|
| gravity | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Гравитация |

<h3 id=entity_set_hanging_facing_location>
  <code>entity::set_hanging_facing_location</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить сторону блока для висящей сущности\
**Тип:** Действие без значения\
**Описание:** Устанавливает висящей сущности сторону блока, на которой она находится.\
**Дополнительная информация:**\
&nbsp;&nbsp;Картины не могут быть размещены сверху или снизу блока.\
**Работает с:**\
&nbsp;&nbsp;Рамками\
&nbsp;&nbsp;Светящимеся рамками\
&nbsp;&nbsp;Картинами

**Пример использования:**
```ts
entity::set_hanging_facing_location("NORTH", "TRUE");

//Или в сухую по ключам

entity::set_hanging_facing_location(facing="NORTH", force="TRUE");
```

**Аргументы:**

| ID     | Тип                                                                                                                             | Описание                            |
|--------|---------------------------------------------------------------------------------------------------------------------------------|-------------------------------------|
| facing | Маркер<br/>**NORTH** - Север<br/>**EAST** - Восток<br/>**SOUTH** - Юг<br/>**WEST** - Запад<br/>**UP** - Верх<br/>**DOWN** - Низ | Сторона блока                       |
| force  | Маркер<br/>**TRUE** - Да<br/>**FALSE** - Нет                                                                                    | Игнорировать доступность размещения |

<h3 id=entity_set_horse_jump>
  <code>entity::set_horse_jump</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить лошади силу прыжка\
**Тип:** Действие без значения\
**Описание:** Устанавливает лошади силу прыжка.\
**Работает с:**\
&nbsp;&nbsp;Лошадьми\
&nbsp;&nbsp;Ослами\
&nbsp;&nbsp;Мулами\
&nbsp;&nbsp;Ламами

**Пример использования:**
```ts
entity::set_horse_jump(1);

//Или в сухую по ключам

entity::set_horse_jump(power=1);
```

**Аргументы:**

| ID    | Тип   | Описание    |
|-------|-------|-------------|
| power | Число | Сила прыжка |

<h3 id=entity_set_horse_pattern>
  <code>entity::set_horse_pattern</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить узор лошади\
**Тип:** Действие без значения\
**Описание:** Устанавливает окрас и узор лошади.\
**Работает с:**\
&nbsp;&nbsp;Лошадьми

**Пример использования:**
```ts
entity::set_horse_pattern("BLACK", "BLACK_DOTS");

//Или в сухую по ключам

entity::set_horse_pattern(horse_color="BLACK", horse_style="BLACK_DOTS");
```

**Аргументы:**

| ID          | Тип                                                                                                                                                                                                                                            | Описание    |
|-------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|
| horse_color | Маркер<br/>**BLACK** - Чёрный<br/>**BROWN** - Коричневый<br/>**CHESTNUT** - Рыжий<br/>**CREAMY** - Бежевый<br/>**DARK_BROWN** - Тёмно-коричневый<br/>**DO_NOT_CHANGE** - Не изменять<br/>**GRAY** - Серый<br/>**WHITE** - Белый                | Цвет лошади |
| horse_style | Маркер<br/>**BLACK_DOTS** - Тёмные пятна на спине<br/>**DO_NOT_CHANGE** - Не изменять<br/>**NONE** - Без узора<br/>**WHITE** - Белые полосы на ногах и голове<br/>**WHITEFIELD** - Крупные белые пятна<br/>**WHITE_DOTS** - Мелкие белые пятна | Узор лошади |

<h3 id=entity_set_immune_to_zombification>
  <code>entity::set_immune_to_zombification</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить иммунитет к зомбифицированию\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу иммунитет к зомбифицированию.\
**Работает с:**\
&nbsp;&nbsp;Пиглинами\
&nbsp;&nbsp;Брутальными пиглинами\
&nbsp;&nbsp;Хоглинами

**Пример использования:**
```ts
entity::set_immune_to_zombification("FALSE");

//Или в сухую по ключам

entity::set_immune_to_zombification(is_immune="FALSE");
```

**Аргументы:**

| ID        | Тип                                                      | Описание                     |
|-----------|----------------------------------------------------------|------------------------------|
| is_immune | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Иммунитет к зомбифицированию |

<h3 id=entity_set_interaction_responsive>
  <code>entity::set_interaction_responsive</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить отзывчивость сущности взаимодействия\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли сущность взаимодействия отзываться на взаимодействия.\
**Работает с:**\
&nbsp;&nbsp;Сущностями взаимодействия

**Пример использования:**
```ts
entity::set_interaction_responsive("FALSE");

//Или в сухую по ключам

entity::set_interaction_responsive(responsive="FALSE");
```

**Аргументы:**

| ID         | Тип                                                      | Описание     |
|------------|----------------------------------------------------------|--------------|
| responsive | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Отзывчивость |

<h3 id=entity_set_interaction_size>
  <code>entity::set_interaction_size</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить размер сущности взаимодействия\
**Тип:** Действие без значения\
**Описание:** Устанавливает горизонтальный и вертикальный размеры сущности взаимодействия.\
**Работает с:**\
&nbsp;&nbsp;Сущностями взаимодействия

**Пример использования:**
```ts
entity::set_interaction_size(1, 2);

//Или в сухую по ключам

entity::set_interaction_size(width=1, height=2);
```

**Аргументы:**

| ID     | Тип   | Описание              |
|--------|-------|-----------------------|
| width  | Число | Горизонтальный размер |
| height | Число | Вертикальный размер   |

<h3 id=entity_set_invisible>
  <code>entity::set_invisible</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим невидимости\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу режим невидимости.

**Пример использования:**
```ts
entity::set_invisible("FALSE");

//Или в сухую по ключам

entity::set_invisible(invisible="FALSE");
```

**Аргументы:**

| ID        | Тип                                                      | Описание          |
|-----------|----------------------------------------------------------|-------------------|
| invisible | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим невидимости |

<h3 id=entity_set_invulnerability_ticks>
  <code>entity::set_invulnerability_ticks</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить длительность неуязвимости\
**Тип:** Действие без значения\
**Описание:** Устанавливает длительность неуязвимости для существа.

**Пример использования:**
```ts
entity::set_invulnerability_ticks(1);

//Или в сухую по ключам

entity::set_invulnerability_ticks(ticks=1);
```

**Аргументы:**

| ID    | Тип   | Описание                            |
|-------|-------|-------------------------------------|
| ticks | Число | Длительность неуязвимости (в тиках) |

<h3 id=entity_set_invulnerable>
  <code>entity::set_invulnerable</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить неуязвимость сущности\
**Тип:** Действие без значения\
**Описание:** Устанавливает неуязвимости сущности, но в режиме креатива можно нанести урон.

**Пример использования:**
```ts
entity::set_invulnerable("FALSE");

//Или в сухую по ключам

entity::set_invulnerable(invulnerable="FALSE");
```

**Аргументы:**

| ID           | Тип                                                      | Описание     |
|--------------|----------------------------------------------------------|--------------|
| invulnerable | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Неуязвимость |

<h3 id=entity_set_item>
  <code>entity::set_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип существу Предмет\
**Тип:** Действие без значения\
**Описание:** Устанавливает определённый тип (ID) существу Предмет.\
**Работает с:**\
&nbsp;&nbsp;Предметами

**Пример использования:**
```ts
entity::set_item(item("stick"));

//Или в сухую по ключам

entity::set_item(item=item("stick"));
```

**Аргументы:**

| ID   | Тип     | Описание              |
|------|---------|-----------------------|
| item | Предмет | Предмет для установки |

<h3 id=entity_set_item_display_item>
  <code>entity::set_item_display_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить отображаемый предмет\
**Тип:** Действие без значения\
**Описание:** Устанавливает отображаемый предмет визуализатору предмета.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами предмета

**Пример использования:**
```ts
entity::set_item_display_item(item("stick"));

//Или в сухую по ключам

entity::set_item_display_item(displayed_item=item("stick"));
```

**Аргументы:**

| ID             | Тип     | Описание             |
|----------------|---------|----------------------|
| displayed_item | Предмет | Отображаемый предмет |

<h3 id=entity_set_item_display_model_type>
  <code>entity::set_item_display_model_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип модели предмета\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип отображаемой модели предмета визуализатору предмета.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами предмета

**Пример использования:**
```ts
entity::set_item_display_model_type("FIRSTPERSON_LEFTHAND");

//Или в сухую по ключам

entity::set_item_display_model_type(display_model_type="FIRSTPERSON_LEFTHAND");
```

**Аргументы:**

| ID                 | Тип                                                                                                                                                                                                                                                                                                                                                                                   | Описание   |
|--------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------|
| display_model_type | Маркер<br/>**FIRSTPERSON_LEFTHAND** - Левая рука от первого лица<br/>**FIRSTPERSON_RIGHTHAND** - Правая рука от первого лица<br/>**FIXED** - Фиксированный<br/>**GROUND** - На земле<br/>**GUI** - Инвентарь<br/>**HEAD** - Голова<br/>**NONE** - Стандартный<br/>**THIRDPERSON_LEFTHAND** - Левая рука от третьего лица<br/>**THIRDPERSON_RIGHTHAND** - Правая рука от третьего лица | Тип модели |

<h3 id=entity_set_item_frame_item_drop_chance>
  <code>entity::set_item_frame_item_drop_chance</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить шанс выпадения предмета из рамки\
**Тип:** Действие без значения\
**Описание:** Устанавливает шанс выпадения предмета из рамки при разрушении.\
**Работает с:**\
&nbsp;&nbsp;Рамками\
&nbsp;&nbsp;Светящимеся рамками

**Пример использования:**
```ts
entity::set_item_frame_item_drop_chance(1);

//Или в сухую по ключам

entity::set_item_frame_item_drop_chance(drop_chance=1);
```

**Аргументы:**

| ID          | Тип   | Описание                        |
|-------------|-------|---------------------------------|
| drop_chance | Число | Шанс (0-100, по умолчанию: 100) |

<h3 id=entity_set_item_in_frame>
  <code>entity::set_item_in_frame</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить предмет в рамку\
**Тип:** Действие без значения\
**Описание:** Устанавливает указанный предмет в рамку.\
**Работает с:**\
&nbsp;&nbsp;Рамками

**Пример использования:**
```ts
entity::set_item_in_frame(item("stick"), "FALSE");

//Или в сухую по ключам

entity::set_item_in_frame(item=item("stick"), play_sound="FALSE");
```

**Аргументы:**

| ID         | Тип                                          | Описание       |
|------------|----------------------------------------------|----------------|
| item       | Предмет                                      | Предмет        |
| play_sound | Маркер<br/>**FALSE** - Нет<br/>**TRUE** - Да | Проиграть звук |

<h3 id=entity_set_item_owner>
  <code>entity::set_item_owner</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить владельца предмета\
**Тип:** Действие без значения\
**Описание:** Устанавливает сущности предмета владельца.\
**Работает с:**\
&nbsp;&nbsp;Предметами

**Пример использования:**
```ts
entity::set_item_owner("name_or_uuid");

//Или в сухую по ключам

entity::set_item_owner(name_or_uuid="name_or_uuid");
```

**Аргументы:**

| ID           | Тип   | Описание               |
|--------------|-------|------------------------|
| name_or_uuid | Текст | Имя или UUID владельца |

<h3 id=entity_set_llama_type>
  <code>entity::set_llama_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цвет ламы\
**Тип:** Действие без значения\
**Описание:** Устанавливает цвет ламы.\
**Работает с:**\
&nbsp;&nbsp;Ламами

**Пример использования:**
```ts
entity::set_llama_type("BROWN");

//Или в сухую по ключам

entity::set_llama_type(type="BROWN");
```

**Аргументы:**

| ID   | Тип                                                                                                   | Описание           |
|------|-------------------------------------------------------------------------------------------------------|--------------------|
| type | Маркер<br/>**BROWN** - Коричневый<br/>**CREAMY** - Бежевый<br/>**GRAY** - Серый<br/>**WHITE** - Белый | Цвет для установки |

<h3 id=entity_set_location>
  <code>entity::set_location</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Запустить по вектору\
**Тип:** Действие без значения\
**Описание:** Запускает существо по указанному вектору.

**Пример использования:**
```ts
entity::set_location(vector(0,0,0), "FALSE");

//Или в сухую по ключам

entity::set_location(velocity=vector(0,0,0), increment="FALSE");
```

**Аргументы:**

| ID        | Тип                                                      | Описание                  |
|-----------|----------------------------------------------------------|---------------------------|
| velocity  | Вектор                                                   | Вектор движения           |
| increment | Маркер<br/>**FALSE** - Выключено<br/>**TRUE** - Включено | Учитывать текущую инерцию |

<h3 id=entity_set_mannequin_description>
  <code>entity::set_mannequin_description</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить описание маникена\
**Тип:** Действие без значения\
**Описание:** Устанавливает описание маникена.\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::set_mannequin_description("description");

//Или в сухую по ключам

entity::set_mannequin_description(description="description");
```

**Аргументы:**

| ID          | Тип   | Описание          |
|-------------|-------|-------------------|
| description | Текст | Описание маникена |

<h3 id=entity_set_mannequin_immovable>
  <code>entity::set_mannequin_immovable</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить передвижение маникена\
**Тип:** Действие без значения\
**Описание:** Устанавливает возможность передвижения для маникена.\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::set_mannequin_immovable("TRUE");

//Или в сухую по ключам

entity::set_mannequin_immovable(immovable="TRUE");
```

**Аргументы:**

| ID        | Тип                                          | Описание                 |
|-----------|----------------------------------------------|--------------------------|
| immovable | Маркер<br/>**TRUE** - Да<br/>**FALSE** - Нет | Возможность передвижения |

<h3 id=entity_set_mannequin_main_hand>
  <code>entity::set_mannequin_main_hand</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить ведущую руку маникена\
**Тип:** Действие без значения\
**Описание:** Устанавливает ведущую руку маникена.\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::set_mannequin_main_hand("RIGHT");

//Или в сухую по ключам

entity::set_mannequin_main_hand(hand="RIGHT");
```

**Аргументы:**

| ID   | Тип                                                | Описание |
|------|----------------------------------------------------|----------|
| hand | Маркер<br/>**RIGHT** - Правая<br/>**LEFT** - Левая | Рука     |

<h3 id=entity_set_mannequin_skin>
  <code>entity::set_mannequin_skin</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить скин маникена\
**Тип:** Действие без значения\
**Описание:** Устанавливает скин маникена.\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::set_mannequin_skin("name_or_uuid", "MOJANG");

//Или в сухую по ключам

entity::set_mannequin_skin(name_or_uuid="name_or_uuid", server_type="MOJANG");
```

**Аргументы:**

| ID           | Тип                                                              | Описание           |
|--------------|------------------------------------------------------------------|--------------------|
| name_or_uuid | Текст                                                            | Имя или UUID скина |
| server_type  | Маркер<br/>**MOJANG** - Скин Mojang<br/>**SERVER** - Скин JustMC | Тип сервера скинов |

<h3 id=entity_set_mannequin_skin_model>
  <code>entity::set_mannequin_skin_model</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип модели маникена\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип модели скина маникена\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::set_mannequin_skin_model("CLASSIC");

//Или в сухую по ключам

entity::set_mannequin_skin_model(model="CLASSIC");
```

**Аргументы:**

| ID    | Тип                                                                                                     | Описание   |
|-------|---------------------------------------------------------------------------------------------------------|------------|
| model | Маркер<br/>**CLASSIC** - Классическая (Стив)<br/>**SLIM** - Тонкая (Алекс)<br/>**UNSET** - По умолчанию | Тип модели |

<h3 id=entity_set_mannequin_skin_parts>
  <code>entity::set_mannequin_skin_parts</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить слои скина маникена\
**Тип:** Действие без значения\
**Описание:** Устанавливает отображение слоев скина маникена.\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::set_mannequin_skin_parts("TRUE", "TRUE", "TRUE", "TRUE", "TRUE", "TRUE", "TRUE");

//Или в сухую по ключам

entity::set_mannequin_skin_parts(hat="TRUE", jacket="TRUE", left_sleeve="TRUE", right_sleeve="TRUE", left_pants="TRUE", right_pants="TRUE", cape="TRUE");
```

**Аргументы:**

| ID           | Тип                                                                                           | Описание    |
|--------------|-----------------------------------------------------------------------------------------------|-------------|
| hat          | Маркер<br/>**TRUE** - Отображать<br/>**FALSE** - Не отображать<br/>**NOT_SET** - По умолчанию | Голова      |
| jacket       | Маркер<br/>**TRUE** - Отображать<br/>**FALSE** - Не отображать<br/>**NOT_SET** - По умолчанию | Туловище    |
| left_sleeve  | Маркер<br/>**TRUE** - Отображать<br/>**FALSE** - Не отображать<br/>**NOT_SET** - По умолчанию | Левая рука  |
| right_sleeve | Маркер<br/>**TRUE** - Отображать<br/>**FALSE** - Не отображать<br/>**NOT_SET** - По умолчанию | Правая рука |
| left_pants   | Маркер<br/>**TRUE** - Отображать<br/>**FALSE** - Не отображать<br/>**NOT_SET** - По умолчанию | Левая нога  |
| right_pants  | Маркер<br/>**TRUE** - Отображать<br/>**FALSE** - Не отображать<br/>**NOT_SET** - По умолчанию | Правая нога |
| cape         | Маркер<br/>**TRUE** - Отображать<br/>**FALSE** - Не отображать<br/>**NOT_SET** - По умолчанию | Плащ        |

<h3 id=entity_set_mannequin_skin_patch>
  <code>entity::set_mannequin_skin_patch</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить текстуру части маникена\
**Тип:** Действие без значения\
**Описание:** Устанавливает текстуру для указанной части маникена.\
**Дополнительная информация:**\
&nbsp;&nbsp;Если не указать аргумент "Ключ текстуры", будет применена текстура по умолчанию.\
**Работает с:**\
&nbsp;&nbsp;Маникенами

**Пример использования:**
```ts
entity::set_mannequin_skin_patch("texture_key", "BODY");

//Или в сухую по ключам

entity::set_mannequin_skin_patch(texture_key="texture_key", patch_target="BODY");
```

**Аргументы:**

| ID           | Тип                                                                    | Описание       |
|--------------|------------------------------------------------------------------------|----------------|
| texture_key  | Текст                                                                  | Ключ текстуры  |
| patch_target | Маркер<br/>**BODY** - Тело<br/>**CAPE** - Плащ<br/>**ELYTRA** - Элитры | Часть маникена |

<h3 id=entity_set_marker>
  <code>entity::set_marker</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим маркера\
**Тип:** Действие без значения\
**Описание:** Устанавливает режим маркера стойке для брони.\
**Работает с:**\
&nbsp;&nbsp;Стойками для брони

**Пример использования:**
```ts
entity::set_marker("FALSE");

//Или в сухую по ключам

entity::set_marker(marker="FALSE");
```

**Аргументы:**

| ID     | Тип                                                      | Описание      |
|--------|----------------------------------------------------------|---------------|
| marker | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим маркера |

<h3 id=entity_set_max_health>
  <code>entity::set_max_health</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить максимальное здоровье существа\
**Тип:** Действие без значения\
**Описание:** Устанавливает максимальное количество здоровья для существа.

**Пример использования:**
```ts
entity::set_max_health(1, "FALSE");

//Или в сухую по ключам

entity::set_max_health(max_health=1, heal_to_max="FALSE");
```

**Аргументы:**

| ID          | Тип                                          | Описание                         |
|-------------|----------------------------------------------|----------------------------------|
| max_health  | Число                                        | Максимальное количество здоровья |
| heal_to_max | Маркер<br/>**FALSE** - Нет<br/>**TRUE** - Да | Исцелить существо                |

<h3 id=entity_set_merchant_recipe>
  <code>entity::set_merchant_recipe</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить товар Жителю\
**Тип:** Действие без значения\
**Описание:** Устанавливает товар Жителю за определённые предметы по указанному индексу.\
**Работает с:**\
&nbsp;&nbsp;Жителями\
&nbsp;&nbsp;Странствующими торговцами

**Пример использования:**
```ts
entity::set_merchant_recipe(item("stick"), 1, 2, item("stick"), 3, item("stick"), 4, 5, 6, 7, "APPEND", "FALSE", "FALSE");

//Или в сухую по ключам

entity::set_merchant_recipe(result=item("stick"), uses=1, max_uses=2, ingredient_one=item("stick"), villager_experience=3, ingredient_two=item("stick"), price_multiplifier=4, demand=5, index=6, special_price=7, mode="APPEND", experience_reward="FALSE", ignore_discounts="FALSE");
```

**Аргументы:**

| ID                  | Тип                                                       | Описание                              |
|---------------------|-----------------------------------------------------------|---------------------------------------|
| result              | Предмет                                                   | Покупаемый товар                      |
| uses                | Число                                                     | Количество использований              |
| max_uses            | Число                                                     | Максимальное количество использований |
| ingredient_one      | Предмет                                                   | Первый предмет                        |
| villager_experience | Число                                                     | Опыт для Жителя                       |
| ingredient_two      | Предмет                                                   | Второй предмет                        |
| price_multiplifier  | Число                                                     | Множитель цены                        |
| demand              | Число                                                     | Спрос товара                          |
| index               | Число                                                     | Индекс товара                         |
| special_price       | Число                                                     | Особая цена                           |
| mode                | Маркер<br/>**APPEND** - Добавление<br/>**MERGE** - Замена | Режим установки                       |
| experience_reward   | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить  | Награда опытом                        |
| ignore_discounts    | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить  | Игнорирование скидок                  |

<h3 id=entity_set_minecart_block>
  <code>entity::set_minecart_block</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить блок в вагонетку\
**Тип:** Действие без значения\
**Описание:** Устанавливает указанный блок в вагонетку.\
**Работает с:**\
&nbsp;&nbsp;Вагонетками

**Пример использования:**
```ts
entity::set_minecart_block("minecraft:oak_log[axis=x]", 1);

//Или в сухую по ключам

entity::set_minecart_block(block="minecraft:oak_log[axis=x]", block_offset=1);
```

**Аргументы:**

| ID           | Тип   | Описание           |
|--------------|-------|--------------------|
| block        | Блок  | Блок для установки |
| block_offset | Число | Сдвиг в блоках     |

<h3 id=entity_set_mob_aggressive>
  <code>entity::set_mob_aggressive</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить агрессивность\
**Тип:** Действие без значения\
**Описание:** Устанавливает агрессивность сущности.\
**Работает с:**\
&nbsp;&nbsp;Утопленниками\
&nbsp;&nbsp;Пиглинами\
&nbsp;&nbsp;Скелетами\
&nbsp;&nbsp;Зомби\
&nbsp;&nbsp;Зомби-жителями\
&nbsp;&nbsp;Иллюзорами\
&nbsp;&nbsp;Поборниками\
&nbsp;&nbsp;Пандами\
&nbsp;&nbsp;Разбойниками\
&nbsp;&nbsp;Брутальными пиглинами

**Пример использования:**
```ts
entity::set_mob_aggressive("FALSE");

//Или в сухую по ключам

entity::set_mob_aggressive(aggressive="FALSE");
```

**Аргументы:**

| ID         | Тип                                          | Описание      |
|------------|----------------------------------------------|---------------|
| aggressive | Маркер<br/>**FALSE** - Нет<br/>**TRUE** - Да | Агрессивность |

<h3 id=entity_set_mushroom_cow_type>
  <code>entity::set_mushroom_cow_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип грибной коровы\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип грибной коровы.\
**Работает с:**\
&nbsp;&nbsp;Грибными коровами

**Пример использования:**
```ts
entity::set_mushroom_cow_type("BROWN");

//Или в сухую по ключам

entity::set_mushroom_cow_type(cow_type="BROWN");
```

**Аргументы:**

| ID       | Тип                                                     | Описание           |
|----------|---------------------------------------------------------|--------------------|
| cow_type | Маркер<br/>**BROWN** - Коричневая<br/>**RED** - Красная | Тип грибной коровы |

<h3 id=entity_set_no_physics>
  <code>entity::no_physics</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить физику для сущности\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу физику.

**Пример использования:**
```ts
entity::no_physics("TRUE");

//Или в сухую по ключам

entity::no_physics(no_physics="TRUE");
```

**Аргументы:**

| ID         | Тип                                          | Описание |
|------------|----------------------------------------------|----------|
| no_physics | Маркер<br/>**TRUE** - Нет<br/>**FALSE** - Да | Физика   |

<h3 id=entity_set_painting_art>
  <code>entity::set_painting_art</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить рисунок картины\
**Тип:** Действие без значения\
**Описание:** Устанавливает рисунок для картины.\
**Работает с:**\
&nbsp;&nbsp;Картинами

**Пример использования:**
```ts
entity::set_painting_art("art", "TRUE");

//Или в сухую по ключам

entity::set_painting_art(art="art", force="TRUE");
```

**Аргументы:**

| ID    | Тип                                          | Описание                            |
|-------|----------------------------------------------|-------------------------------------|
| art   | Текст                                        | Ключ рисунка картины                |
| force | Маркер<br/>**TRUE** - Да<br/>**FALSE** - Нет | Игнорировать доступность размещения |

<h3 id=entity_set_panda_gene>
  <code>entity::set_panda_gene</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить ген панды\
**Тип:** Действие без значения\
**Описание:** Устанавливает ген панды. Это влияет на их поведение и внешний вид.\
**Работает с:**\
&nbsp;&nbsp;Пандами

**Пример использования:**
```ts
entity::set_panda_gene("BOTH", "AGGRESSIVE");

//Или в сухую по ключам

entity::set_panda_gene(gene="BOTH", gene_type="AGGRESSIVE");
```

**Аргументы:**

| ID        | Тип                                                                                                                                                                                            | Описание |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|
| gene      | Маркер<br/>**BOTH** - Оба гена<br/>**HIDDEN** - Скрытый ген<br/>**MAIN** - Главный ген                                                                                                         | Ген      |
| gene_type | Маркер<br/>**AGGRESSIVE** - Агрессивный<br/>**BROWN** - Суровый<br/>**LAZY** - Ленивый<br/>**NORMAL** - Нормальный<br/>**PLAYFUL** - Игривый<br/>**WEAK** - Слабый<br/>**WORRIED** - Тревожный | Тип гена |

<h3 id=entity_set_panda_on_back>
  <code>entity::set_panda_on_back</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Посадить панду\
**Тип:** Действие без значения\
**Описание:** Устанавливает Панде состояние сидения.\
**Работает с:**\
&nbsp;&nbsp;Пандами

**Пример использования:**
```ts
entity::set_panda_on_back("TRUE");

//Или в сухую по ключам

entity::set_panda_on_back(on_back="TRUE");
```

**Аргументы:**

| ID      | Тип                                          | Описание          |
|---------|----------------------------------------------|-------------------|
| on_back | Маркер<br/>**TRUE** - Да<br/>**FALSE** - Нет | Состояние сидения |

<h3 id=entity_set_panda_rolling>
  <code>entity::set_panda_rolling</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить Панде состояние переката\
**Тип:** Действие без значения\
**Описание:** Устанавливает Панде состояние переката.\
**Работает с:**\
&nbsp;&nbsp;Пандами

**Пример использования:**
```ts
entity::set_panda_rolling("TRUE");

//Или в сухую по ключам

entity::set_panda_rolling(rolling="TRUE");
```

**Аргументы:**

| ID      | Тип                                          | Описание           |
|---------|----------------------------------------------|--------------------|
| rolling | Маркер<br/>**TRUE** - Да<br/>**FALSE** - Нет | Состояние переката |

<h3 id=entity_set_panda_sad_ticks>
  <code>entity::set_panda_sad_ticks</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить время грусти Панды\
**Тип:** Действие без значения\
**Описание:** Устанавливает время грусти Панды в тиках.\
**Работает с:**\
&nbsp;&nbsp;Пандами

**Пример использования:**
```ts
entity::set_panda_sad_ticks(1);

//Или в сухую по ключам

entity::set_panda_sad_ticks(sad_ticks=1);
```

**Аргументы:**

| ID        | Тип   | Описание     |
|-----------|-------|--------------|
| sad_ticks | Число | Время грусти |

<h3 id=entity_set_parrot_type>
  <code>entity::set_parrot_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип попугая\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип попугая.\
**Работает с:**\
&nbsp;&nbsp;Попугаями

**Пример использования:**
```ts
entity::set_parrot_type("BLUE");

//Или в сухую по ключам

entity::set_parrot_type(parrot_type="BLUE");
```

**Аргументы:**

| ID          | Тип                                                                                                                     | Описание    |
|-------------|-------------------------------------------------------------------------------------------------------------------------|-------------|
| parrot_type | Маркер<br/>**BLUE** - Синий<br/>**CYAN** - Бирюзовый<br/>**GRAY** - Серый<br/>**GREEN** - Зелёный<br/>**RED** - Красный | Тип попугая |

<h3 id=entity_set_persistence>
  <code>entity::set_persistence</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить исчезание существа\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли предмет или падающий блок исчезать.\
**Работает с:**\
&nbsp;&nbsp;Предметами\
&nbsp;&nbsp;Падающими блоками

**Пример использования:**
```ts
entity::set_persistence("FALSE");

//Или в сухую по ключам

entity::set_persistence(persistence="FALSE");
```

**Аргументы:**

| ID          | Тип                                                                    | Описание           |
|-------------|------------------------------------------------------------------------|--------------------|
| persistence | Маркер<br/>**FALSE** - Будет исчезать<br/>**TRUE** - Не будет исчезать | Исчезание существа |

<h3 id=entity_set_persistent>
  <code>entity::set_persistent</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить сущности сохранение\
**Тип:** Действие без значения\
**Описание:** Устанавливает сущности состояние, будет ли она сохранена после отгрузки мира.

**Пример использования:**
```ts
entity::set_persistent("TRUE");

//Или в сухую по ключам

entity::set_persistent(persistent="TRUE");
```

**Аргументы:**

| ID         | Тип                                                     | Описание            |
|------------|---------------------------------------------------------|---------------------|
| persistent | Маркер<br/>**TRUE** - Сохранять<br/>**FALSE** - Удалять | Сохранение сущности |

<h3 id=entity_set_pickup>
  <code>entity::set_pickup</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить возможность подбора\
**Тип:** Действие без значения\
**Описание:** Устанавливает сущности возможность подбора.\
**Работает с:**\
&nbsp;&nbsp;Сущностями предметов

**Пример использования:**
```ts
entity::set_pickup("TRUE", "TRUE");

//Или в сухую по ключам

entity::set_pickup(can_mob_pickup="TRUE", can_player_pickup="TRUE");
```

**Аргументы:**

| ID                | Тип                                                    | Описание        |
|-------------------|--------------------------------------------------------|-----------------|
| can_mob_pickup    | Маркер<br/>**TRUE** - Включен<br/>**FALSE** - Отключен | Подбор мобами   |
| can_player_pickup | Маркер<br/>**TRUE** - Включен<br/>**FALSE** - Отключен | Подбор игроками |

<h3 id=entity_set_pickup_delay>
  <code>entity::set_pickup_delay</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить задержку для поднятия\
**Тип:** Действие без значения\
**Описание:** Устанавливает количество тиков, за которое предмет не может быть поднят.\
**Работает с:**\
&nbsp;&nbsp;Предметами

**Пример использования:**
```ts
entity::set_pickup_delay(1);

//Или в сухую по ключам

entity::set_pickup_delay(delay=1);
```

**Аргументы:**

| ID    | Тип   | Описание |
|-------|-------|----------|
| delay | Число | Задержка |

<h3 id=entity_set_pig_type>
  <code>entity::set_pig_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип Свиньи\
**Тип:** Действие без значения\
**Описание:** Устанавливает свинье тип окраски.\
**Работает с:**\
&nbsp;&nbsp;Свиньями

**Пример использования:**
```ts
entity::set_pig_type("COLD");

//Или в сухую по ключам

entity::set_pig_type(variant="COLD");
```

**Аргументы:**

| ID      | Тип                                                                                  | Описание    |
|---------|--------------------------------------------------------------------------------------|-------------|
| variant | Маркер<br/>**COLD** - Снежная<br/>**WARM** - Тропическая<br/>**TEMPERATE** - Обычная | Тип окраски |

<h3 id=entity_set_piglin_able_to_hunt>
  <code>entity::set_piglin_able_to_hunt</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить состояние охоты\
**Тип:** Действие без значения\
**Описание:** Устанавливает пиглину состояние охоты на хоглинов.\
**Работает с:**\
&nbsp;&nbsp;Пиглинами

**Пример использования:**
```ts
entity::set_piglin_able_to_hunt("FALSE");

//Или в сухую по ключам

entity::set_piglin_able_to_hunt(able="FALSE");
```

**Аргументы:**

| ID   | Тип                                                        | Описание        |
|------|------------------------------------------------------------|-----------------|
| able | Маркер<br/>**FALSE** - Не охотится<br/>**TRUE** - Охотится | Состояние охоты |

<h3 id=entity_set_piglin_charging_crossbow>
  <code>entity::set_piglin_charging_crossbow</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить состояние зарядки арбалета\
**Тип:** Действие без значения\
**Описание:** Устанавливает пиглину состояние зарядки арбалета.\
**Работает с:**\
&nbsp;&nbsp;Пиглинами

**Пример использования:**
```ts
entity::set_piglin_charging_crossbow("FALSE");

//Или в сухую по ключам

entity::set_piglin_charging_crossbow(charging="FALSE");
```

**Аргументы:**

| ID       | Тип                                                        | Описание          |
|----------|------------------------------------------------------------|-------------------|
| charging | Маркер<br/>**FALSE** - Не заряжать<br/>**TRUE** - Заряжать | Состояние зарядки |

<h3 id=entity_set_piglin_dancing>
  <code>entity::set_piglin_dancing</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить стадию танца\
**Тип:** Действие без значения\
**Описание:** Устанавливает пиглину стадию танца на указанное время.\
**Дополнительная информация:**\
&nbsp;&nbsp;Если значение продолжительности меньше 0, то танец будет длиться бесконечно.\
**Работает с:**\
&nbsp;&nbsp;Пиглинами

**Пример использования:**
```ts
entity::set_piglin_dancing(1);

//Или в сухую по ключам

entity::set_piglin_dancing(dancing_time=1);
```

**Аргументы:**

| ID           | Тип   | Описание                          |
|--------------|-------|-----------------------------------|
| dancing_time | Число | Продолжительность танца (в тиках) |

<h3 id=entity_set_pose>
  <code>entity::set_pose</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить позу сущности\
**Тип:** Действие без значения\
**Описание:** Устанавливает определённую позу существу.

**Пример использования:**
```ts
entity::set_pose("CROAKING");

//Или в сухую по ключам

entity::set_pose(pose="CROAKING");
```

**Аргументы:**

| ID   | Тип                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Описание          |
|------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|
| pose | Маркер<br/>**CROAKING** - Кваканье (для Жаб)<br/>**CROUCHING** - Приседание<br/>**DIGGING** - Зарывание в землю (для Хранителя)<br/>**DYING** - Смерть<br/>**EMERGING** - Появление из земли (для Хранителя)<br/>**FALL_FLYING** - Полёт на Элитрах<br/>**INHALING** - Вдыхание (для Вихря)<br/>**LONG_JUMPING** - Длинный прыжок<br/>**ROARING** - Рёв (для Хранителя)<br/>**SHOOTING** - Выстреливание (для Вихря)<br/>**SITTING** - Сидение<br/>**SLEEPING** - Лежание<br/>**SLIDING** - Скольжение (для Вихря)<br/>**SNEAKING** - creative_plus.action.entity_set_pose.argument.pose.enum.sneaking.name<br/>**SNIFFING** - Нюханье (для Хранителя)<br/>**SPIN_ATTACK** - Использование Тягуна<br/>**STANDING** - Обычное состояние<br/>**SWIMMING** - Плавание<br/>**USING_TONGUE** - Использование языка (для Жаб) | Отображаемая поза |

<h3 id=entity_set_potion_cloud_radius>
  <code>entity::set_potion_cloud_radius</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить радиус облака эффекта\
**Тип:** Действие без значения\
**Описание:** Устанавливает радиус облака эффекта и скорость его расширения.\
**Дополнительная информация:**\
&nbsp;&nbsp;Скорость расширения - величина изменения радиуса за тик, может быть отрицательной.\
**Работает с:**\
&nbsp;&nbsp;Облаком эффекта

**Пример использования:**
```ts
entity::set_potion_cloud_radius(1, 2);

//Или в сухую по ключам

entity::set_potion_cloud_radius(radius=1, shrinking_speed=2);
```

**Аргументы:**

| ID              | Тип   | Описание |
|-----------------|-------|----------|
| radius          | Число | Радиус   |
| shrinking_speed | Число | Скорость |

<h3 id=entity_set_primed_tnt_block>
  <code>entity::set_primed_tnt_block</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Замаскировать зажжённый динамит под блок\
**Тип:** Действие без значения\
**Описание:** Маскирует зажжённый динамит под указанный блок.\
**Работает с:**\
&nbsp;&nbsp;Зажжённым динамитом

**Пример использования:**
```ts
entity::set_primed_tnt_block("minecraft:oak_log[axis=x]");

//Или в сухую по ключам

entity::set_primed_tnt_block(block="minecraft:oak_log[axis=x]");
```

**Аргументы:**

| ID    | Тип  | Описание |
|-------|------|----------|
| block | Блок | Блок     |

<h3 id=entity_set_projectile_display_item>
  <code>entity::set_projectile_display_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить предмет снаряда\
**Тип:** Действие без значения\
**Описание:** Устанавливает видимый предмет снаряду.\
**Работает с:**\
&nbsp;&nbsp;Снежками\
&nbsp;&nbsp;Яйцами\
&nbsp;&nbsp;Огненными шарами\
&nbsp;&nbsp;Огненными шарами Гаста\
&nbsp;&nbsp;Эндер-жемчугами\
&nbsp;&nbsp;Пузырьками опыта\
&nbsp;&nbsp;Очами Края\
&nbsp;&nbsp;Брошенными зельями

**Пример использования:**
```ts
entity::set_projectile_display_item(item("stick"));

//Или в сухую по ключам

entity::set_projectile_display_item(item=item("stick"));
```

**Аргументы:**

| ID   | Тип     | Описание              |
|------|---------|-----------------------|
| item | Предмет | Предмет для установки |

<h3 id=entity_set_projectile_power>
  <code>entity::set_projectile_power</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить снаряду вектор движения\
**Тип:** Действие без значения\
**Описание:** Устанавливает снаряду вектор движения.\
**Работает с:**\
&nbsp;&nbsp;Огненными шарами\
&nbsp;&nbsp;Зарядами дракона\
&nbsp;&nbsp;Головами Иссушителя

**Пример использования:**
```ts
entity::set_projectile_power(vector(0,0,0));

//Или в сухую по ключам

entity::set_projectile_power(power=vector(0,0,0));
```

**Аргументы:**

| ID    | Тип    | Описание        |
|-------|--------|-----------------|
| power | Вектор | Вектор движения |

<h3 id=entity_set_projectile_shooter>
  <code>entity::set_projectile_shooter</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить стрелка снаряду\
**Тип:** Действие без значения\
**Описание:** Устанавливает указанное существо как стрелка для снаряда.

**Пример использования:**
```ts
entity::set_projectile_shooter("uuid");

//Или в сухую по ключам

entity::set_projectile_shooter(uuid="uuid");
```

**Аргументы:**

| ID   | Тип   | Описание             |
|------|-------|----------------------|
| uuid | Текст | Имя или UUID стрелка |

<h3 id=entity_set_rabbit_type>
  <code>entity::set_rabbit_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип кролика\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип кролика.\
**Работает с:**\
&nbsp;&nbsp;Кроликами

**Пример использования:**
```ts
entity::set_rabbit_type("BLACK");

//Или в сухую по ключам

entity::set_rabbit_type(rabbit_type="BLACK");
```

**Аргументы:**

| ID          | Тип                                                                                                                                                                                                                            | Описание    |
|-------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|
| rabbit_type | Маркер<br/>**BLACK** - Чёрный<br/>**BLACK_AND_WHITE** - Чёрно-белый<br/>**BROWN** - Коричневый<br/>**GOLD** - Золотой<br/>**SALT_AND_PEPPER** - Бело-коричневый<br/>**THE_KILLER_BUNNY** - Кролик-убийца<br/>**WHITE** - Белый | Тип кролика |

<h3 id=entity_set_rearing>
  <code>entity::set_rearing</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить позу лошади\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли лошадь стоять на задних ногах.\
**Работает с:**\
&nbsp;&nbsp;Лошадьми

**Пример использования:**
```ts
entity::set_rearing("FALSE");

//Или в сухую по ключам

entity::set_rearing(rearing="FALSE");
```

**Аргументы:**

| ID      | Тип                                                                            | Описание    |
|---------|--------------------------------------------------------------------------------|-------------|
| rearing | Маркер<br/>**FALSE** - Обычное состояние<br/>**TRUE** - Стоять на задних ногах | Поза лошади |

<h3 id=entity_set_riptiding>
  <code>entity::set_riptiding</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить анимацию Тягун\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу анимацию использования зачарования трезубца Тягун.

**Пример использования:**
```ts
entity::set_riptiding("FALSE");

//Или в сухую по ключам

entity::set_riptiding(riptiding="FALSE");
```

**Аргументы:**

| ID        | Тип                                                      | Описание         |
|-----------|----------------------------------------------------------|------------------|
| riptiding | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Анимация 'Тягун' |

<h3 id=entity_set_rotation>
  <code>entity::set_rotation</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить поворот\
**Тип:** Действие без значения\
**Описание:** Устанавливает поворот сущности.

**Пример использования:**
```ts
entity::set_rotation(1, 2);

//Или в сухую по ключам

entity::set_rotation(yaw=1, pitch=2);
```

**Аргументы:**

| ID    | Тип   | Описание                     |
|-------|-------|------------------------------|
| yaw   | Число | Горизонтальный поворот (yaw) |
| pitch | Число | Вертикальный поворот (pitch) |

<h3 id=entity_set_rotation_by_vector>
  <code>entity::set_rotation_by_vector</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить поворот по вектору\
**Тип:** Действие без значения\
**Описание:** Устанавливает поворот сущности по вектору.

**Пример использования:**
```ts
entity::set_rotation_by_vector(vector(0,0,0));

//Или в сухую по ключам

entity::set_rotation_by_vector(vector=vector(0,0,0));
```

**Аргументы:**

| ID     | Тип    | Описание            |
|--------|--------|---------------------|
| vector | Вектор | Вектор для поворота |

<h3 id=entity_set_sheep_sheared>
  <code>entity::set_sheep_sheared</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить шерсть овце\
**Тип:** Действие без значения\
**Описание:** Устанавливает, будет ли шерсть на овце.\
**Работает с:**\
&nbsp;&nbsp;Овцами

**Пример использования:**
```ts
entity::set_sheep_sheared("FALSE");

//Или в сухую по ключам

entity::set_sheep_sheared(sheared="FALSE");
```

**Аргументы:**

| ID      | Тип                                                        | Описание           |
|---------|------------------------------------------------------------|--------------------|
| sheared | Маркер<br/>**FALSE** - Без шерсти<br/>**TRUE** - С шерстью | Присутствие шерсти |

<h3 id=entity_set_shulker_bullet_target>
  <code>entity::set_shulker_bullet_target</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цель снаряду Шалкера\
**Тип:** Действие без значения\
**Описание:** Устанавливает цель атаки снаряду Шалкера.\
**Работает с:**\
&nbsp;&nbsp;Снарядами Шалкера

**Пример использования:**
```ts
entity::set_shulker_bullet_target("target");

//Или в сухую по ключам

entity::set_shulker_bullet_target(target="target");
```

**Аргументы:**

| ID     | Тип   | Описание          |
|--------|-------|-------------------|
| target | Текст | Имя или UUID цели |

<h3 id=entity_set_shulker_peek>
  <code>entity::set_shulker_peek</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить процент открытия шалкера\
**Тип:** Действие без значения\
**Описание:** Устанавливает шалкеру процент, на который он открыт.\
**Работает с:**\
&nbsp;&nbsp;Шалкерами

**Пример использования:**
```ts
entity::set_shulker_peek(1, "TRUE");

//Или в сухую по ключам

entity::set_shulker_peek(rolling=1, silent="TRUE");
```

**Аргументы:**

| ID      | Тип                                          | Описание                     |
|---------|----------------------------------------------|------------------------------|
| rolling | Число                                        | Процент открытия             |
| silent  | Маркер<br/>**TRUE** - Нет<br/>**FALSE** - Да | Звук от изменения открытости |

<h3 id=entity_set_silenced>
  <code>entity::set_silenced</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Заглушить сущность\
**Тип:** Действие без значения\
**Описание:** Убирает звуки сущности.

**Пример использования:**
```ts
entity::set_silenced("FALSE");

//Или в сухую по ключам

entity::set_silenced(silenced="FALSE");
```

**Аргументы:**

| ID       | Тип                                                      | Описание   |
|----------|----------------------------------------------------------|------------|
| silenced | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Заглушение |

<h3 id=entity_set_sitting>
  <code>entity::set_sitting</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить режим сидения\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу режим сидения.\
**Работает с:**\
&nbsp;&nbsp;Волками\
&nbsp;&nbsp;Кошками\
&nbsp;&nbsp;Попугаями\
&nbsp;&nbsp;Лисами\
&nbsp;&nbsp;Пандами

**Пример использования:**
```ts
entity::set_sitting("FALSE");

//Или в сухую по ключам

entity::set_sitting(sitting="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание      |
|---------|----------------------------------------------------------|---------------|
| sitting | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим сидения |

<h3 id=entity_set_size>
  <code>entity::set_size</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить размер существа\
**Тип:** Действие без значения\
**Описание:** Устанавливает размер существу.\
**Работает с:**\
&nbsp;&nbsp;Слизнями\
&nbsp;&nbsp;Фантомами

**Пример использования:**
```ts
entity::set_size(1);

//Или в сухую по ключам

entity::set_size(size=1);
```

**Аргументы:**

| ID   | Тип   | Описание |
|------|-------|----------|
| size | Число | Размер   |

<h3 id=entity_set_sniffer_state>
  <code>entity::set_sniffer_state</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить состояние нюхача\
**Тип:** Действие без значения\
**Описание:** Устанавливает определённое состояние нюхачу.\
**Работает с:**\
&nbsp;&nbsp;Нюхачами

**Пример использования:**
```ts
entity::set_sniffer_state("DIGGING");

//Или в сухую по ключам

entity::set_sniffer_state(state="DIGGING");
```

**Аргументы:**

| ID    | Тип                                                                                                                                                                                                                                  | Описание         |
|-------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|
| state | Маркер<br/>**DIGGING** - Копает<br/>**FEELING_HAPPY** - Чувстует себя счастливым<br/>**IDLING** - Обычное состояние<br/>**RISING** - Поднимается<br/>**SCENTING** - Идёт по следу<br/>**SEARCHING** - Ищет<br/>**SNIFFING** - Нюхает | Состояние нюхача |

<h3 id=entity_set_snowman_pumpkin>
  <code>entity::set_snowman_pumpkin</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тыкву снеговику\
**Тип:** Действие без значения\
**Описание:** Устанавливает видимость тыквы снеговику.\
**Работает с:**\
&nbsp;&nbsp;Снежными големами

**Пример использования:**
```ts
entity::set_snowman_pumpkin("FALSE");

//Или в сухую по ключам

entity::set_snowman_pumpkin(pumpkin="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание        |
|---------|----------------------------------------------------------|-----------------|
| pumpkin | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Видимость тыквы |

<h3 id=entity_set_tame>
  <code>entity::set_tame</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Приручить существо\
**Тип:** Действие без значения\
**Описание:** Устанавливает привязанность существа к указанному хозяину.\
**Работает с:**\
&nbsp;&nbsp;Волками\
&nbsp;&nbsp;Кошками\
&nbsp;&nbsp;Лошадьми\
&nbsp;&nbsp;Мулами\
&nbsp;&nbsp;Ламами\
&nbsp;&nbsp;Попугаями

**Пример использования:**
```ts
entity::set_tame("name_or_uuid");

//Или в сухую по ключам

entity::set_tame(name_or_uuid="name_or_uuid");
```

**Аргументы:**

| ID           | Тип   | Описание             |
|--------------|-------|----------------------|
| name_or_uuid | Текст | Имя или UUID хозяина |

<h3 id=entity_set_target>
  <code>entity::set_target</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цель существу\
**Тип:** Действие без значения\
**Описание:** Инструктирует ИИ существа нацеливаться на определённое существо.\
**Дополнительная информация:**\
&nbsp;&nbsp;Оставьте пустой слот в поле Текст, чтобы убрать цель.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::set_target("name_or_uuid");

//Или в сухую по ключам

entity::set_target(name_or_uuid="name_or_uuid");
```

**Аргументы:**

| ID           | Тип   | Описание          |
|--------------|-------|-------------------|
| name_or_uuid | Текст | Имя или UUID цели |

<h3 id=entity_set_text_display_alignment>
  <code>entity::set_text_display_alignment</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить выравнивание текста\
**Тип:** Действие без значения\
**Описание:** Устанавливает выравнивание текста визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::set_text_display_alignment("CENTER");

//Или в сухую по ключам

entity::set_text_display_alignment(text_alignment="CENTER");
```

**Аргументы:**

| ID             | Тип                                                                           | Описание            |
|----------------|-------------------------------------------------------------------------------|---------------------|
| text_alignment | Маркер<br/>**CENTER** - По центру<br/>**LEFT** - Слева<br/>**RIGHT** - Справа | Выравнивание текста |

<h3 id=entity_set_text_display_background>
  <code>entity::set_text_display_background</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цвет фона\
**Тип:** Действие без значения\
**Описание:** Устанавливает цвет и прозрачность фона визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::set_text_display_background("color_hexadecimal", 1);

//Или в сухую по ключам

entity::set_text_display_background(color_hexadecimal="color_hexadecimal", opacity=1);
```

**Аргументы:**

| ID                | Тип   | Описание               |
|-------------------|-------|------------------------|
| color_hexadecimal | Текст | HEX цвет               |
| opacity           | Число | Процент непрозрачности |

<h3 id=entity_set_text_display_line_width>
  <code>entity::set_text_display_line_width</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить ширину строки\
**Тип:** Действие без значения\
**Описание:** Устанавливает максимальную ширину строки визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::set_text_display_line_width(1);

//Или в сухую по ключам

entity::set_text_display_line_width(line_width=1);
```

**Аргументы:**

| ID         | Тип   | Описание      |
|------------|-------|---------------|
| line_width | Число | Ширина строки |

<h3 id=entity_set_text_display_opacity>
  <code>entity::set_text_display_opacity</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить прозрачность текста\
**Тип:** Действие без значения\
**Описание:** Устанавливает прозрачность текста визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::set_text_display_opacity(1);

//Или в сухую по ключам

entity::set_text_display_opacity(text_opacity=1);
```

**Аргументы:**

| ID           | Тип   | Описание            |
|--------------|-------|---------------------|
| text_opacity | Число | Прозрачность текста |

<h3 id=entity_set_text_display_see_through>
  <code>entity::set_text_display_see_through</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить видимость через блоки\
**Тип:** Действие без значения\
**Описание:** Устанавливает видимость текста через блоки визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::set_text_display_see_through("FALSE");

//Или в сухую по ключам

entity::set_text_display_see_through(enable_see_through="FALSE");
```

**Аргументы:**

| ID                 | Тип                                                      | Описание              |
|--------------------|----------------------------------------------------------|-----------------------|
| enable_see_through | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Видимость через блоки |

<h3 id=entity_set_text_display_text>
  <code>entity::set_text_display_text</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить отображаемый текст\
**Тип:** Действие без значения\
**Описание:** Устанавливает отображаемый текст визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::set_text_display_text(["displayed_text", "displayed_text"], "CONCATENATION");

//Или в сухую по ключам

entity::set_text_display_text(displayed_text=["displayed_text", "displayed_text"], merging_mode="CONCATENATION");
```

**Аргументы:**

| ID             | Тип                                                                                                                           | Описание                                                        |
|----------------|-------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------|
| displayed_text | Список\[Текст\]                                                                                                               | Отображаемый текст<br/>Аргумент поддерживает разложение списков |
| merging_mode   | Маркер<br/>**CONCATENATION** - Объединение<br/>**SEPARATE_LINES** - Разделение на строки<br/>**SPACES** - Разделение пробелом | Объединение текста                                              |

<h3 id=entity_set_text_display_text_shadow>
  <code>entity::set_text_display_text_shadow</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тень текста\
**Тип:** Действие без значения\
**Описание:** Устанавливает видимость тени текста визуализатору текста.\
**Работает с:**\
&nbsp;&nbsp;Визуализаторами текста

**Пример использования:**
```ts
entity::set_text_display_text_shadow("FALSE");

//Или в сухую по ключам

entity::set_text_display_text_shadow(enable_text_shadow="FALSE");
```

**Аргументы:**

| ID                 | Тип                                                      | Описание    |
|--------------------|----------------------------------------------------------|-------------|
| enable_text_shadow | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Тень текста |

<h3 id=entity_set_tropical_fish_pattern>
  <code>entity::set_tropical_fish_pattern</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить узор рыбы\
**Тип:** Действие без значения\
**Описание:** Устанавливает окрас и узор тропической рыбе.\
**Работает с:**\
&nbsp;&nbsp;Тропической рыбой

**Пример использования:**
```ts
entity::set_tropical_fish_pattern("BLACK", "BLACK", "BETTY");

//Или в сухую по ключам

entity::set_tropical_fish_pattern(pattern_color="BLACK", body_color="BLACK", pattern="BETTY");
```

**Аргументы:**

| ID            | Тип                                                                                                                                                                                                                                                                                                                                                                                                                                                          | Описание   |
|---------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------|
| pattern_color | Маркер<br/>**BLACK** - Чёрный<br/>**BLUE** - Синий<br/>**BROWN** - Коричневый<br/>**CYAN** - Бирюзовый<br/>**DO_NOT_CHANGE** - Не изменять<br/>**GRAY** - Серый<br/>**GREEN** - Зелёный<br/>**LIGHT_BLUE** - Голубой<br/>**LIGHT_GRAY** - Светло-серый<br/>**LIME** - Лаймовый<br/>**MAGENTA** - Пурпурный<br/>**ORANGE** - Оранжевый<br/>**PINK** - Розовый<br/>**PURPLE** - Фиолетовый<br/>**RED** - Красный<br/>**WHITE** - Белый<br/>**YELLOW** - Жёлтый | Цвет узора |
| body_color    | Маркер<br/>**BLACK** - Чёрный<br/>**BLUE** - Синий<br/>**BROWN** - Коричневый<br/>**CYAN** - Бирюзовый<br/>**DO_NOT_CHANGE** - Не изменять<br/>**GRAY** - Серый<br/>**GREEN** - Зелёный<br/>**LIGHT_BLUE** - Голубой<br/>**LIGHT_GRAY** - Светло-серый<br/>**LIME** - Лаймовый<br/>**MAGENTA** - Пурпурный<br/>**ORANGE** - Оранжевый<br/>**PINK** - Розовый<br/>**PURPLE** - Фиолетовый<br/>**RED** - Красный<br/>**WHITE** - Белый<br/>**YELLOW** - Жёлтый | Цвет тела  |
| pattern       | Маркер<br/>**BETTY** - Betty<br/>**BLOCKFISH** - Blockfish<br/>**BRINELY** - Brinely<br/>**CLAYFISH** - Clayfish<br/>**DASHER** - Dasher<br/>**DO_NOT_CHANGE** - Не изменять<br/>**FLOPPER** - Flopper<br/>**GLITTER** - Glitter<br/>**KOB** - Kob<br/>**SNOOPER** - Snooper<br/>**SPOTTY** - Spotty<br/>**STRIPEY** - Stripey<br/>**SUNSTREAK** - SunStreak                                                                                                 | Узор       |

<h3 id=entity_set_vex_charging>
  <code>entity::set_vex_charging</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить Вредине злость\
**Тип:** Действие без значения\
**Описание:** Устанавливает Вредине стадию злости.\
**Работает с:**\
&nbsp;&nbsp;Врединами

**Пример использования:**
```ts
entity::set_vex_charging("FALSE");

//Или в сухую по ключам

entity::set_vex_charging(charging="FALSE");
```

**Аргументы:**

| ID       | Тип                                                | Описание      |
|----------|----------------------------------------------------|---------------|
| charging | Маркер<br/>**FALSE** - Не злой<br/>**TRUE** - Злой | Стадия злости |

<h3 id=entity_set_vex_limited_lifetime_ticks>
  <code>entity::set_vex_limited_lifetime_ticks</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить время жизни Вредины\
**Тип:** Действие без значения\
**Описание:** Устанавливает время жизни Вредины в тиках.\
**Работает с:**\
&nbsp;&nbsp;Врединами

**Пример использования:**
```ts
entity::set_vex_limited_lifetime_ticks(1);

//Или в сухую по ключам

entity::set_vex_limited_lifetime_ticks(lifetime=1);
```

**Аргументы:**

| ID       | Тип   | Описание    |
|----------|-------|-------------|
| lifetime | Число | Время жизни |

<h3 id=entity_set_villager_biome>
  <code>entity::set_villager_biome</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить биом жителю\
**Тип:** Действие без значения\
**Описание:** Устанавливает жителю окрас в зависимости от выбранного биома.\
**Работает с:**\
&nbsp;&nbsp;Жителями

**Пример использования:**
```ts
entity::set_villager_biome("DESERT");

//Или в сухую по ключам

entity::set_villager_biome(biome="DESERT");
```

**Аргументы:**

| ID    | Тип                                                                                                                                                                               | Описание |
|-------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|
| biome | Маркер<br/>**DESERT** - Пустынный<br/>**JUNGLE** - Джунгли<br/>**PLAINS** - Равнины<br/>**SAVANNA** - Саванна<br/>**SNOW** - Снежный<br/>**SWAMP** - Болото<br/>**TAIGA** - Тайга | Биом     |

<h3 id=entity_set_villager_experience>
  <code>entity::set_villager_experience</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить опыт жителю\
**Тип:** Действие без значения\
**Описание:** Устанавливает жителю количество опыта.\
**Работает с:**\
&nbsp;&nbsp;Жителями

**Пример использования:**
```ts
entity::set_villager_experience(1);

//Или в сухую по ключам

entity::set_villager_experience(experience=1);
```

**Аргументы:**

| ID         | Тип   | Описание         |
|------------|-------|------------------|
| experience | Число | Количество опыта |

<h3 id=entity_set_villager_profession>
  <code>entity::set_villager_profession</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить профессию жителю\
**Тип:** Действие без значения\
**Описание:** Устанавливает определённую профессию жителю.\
**Работает с:**\
&nbsp;&nbsp;Жителями\
&nbsp;&nbsp;Зомби-жителями

**Пример использования:**
```ts
entity::set_villager_profession("ARMORER");

//Или в сухую по ключам

entity::set_villager_profession(profession="ARMORER");
```

**Аргументы:**

| ID         | Тип                                                                                                                                                                                                                                                                                                                                                                                                                                             | Описание         |
|------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------|
| profession | Маркер<br/>**ARMORER** - Бронник<br/>**BUTCHER** - Мясник<br/>**CARTOGRAPHER** - Картограф<br/>**CLERIC** - Священник<br/>**FARMER** - Фермер<br/>**FISHERMAN** - Рыбак<br/>**FLETCHER** - Лучник<br/>**LEATHERWORKER** - Кожевник<br/>**LIBRARIAN** - Библиотекарь<br/>**MASON** - Каменщик<br/>**NITWIT** - Нищий<br/>**NONE** - Без профессии<br/>**SHEPHERD** - Пастух<br/>**TOOLSMITH** - Инструментальщик<br/>**WEAPONSMITH** - Оружейник | Профессия жителя |

<h3 id=entity_set_visual_fire>
  <code>entity::set_visual_fire</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Отображать огонь\
**Тип:** Действие без значения\
**Описание:** Отображает огонь на существе.

**Пример использования:**
```ts
entity::set_visual_fire("FALSE");

//Или в сухую по ключам

entity::set_visual_fire(visual_fire="FALSE");
```

**Аргументы:**

| ID          | Тип                                                                                     | Описание         |
|-------------|-----------------------------------------------------------------------------------------|------------------|
| visual_fire | Маркер<br/>**FALSE** - Выключить<br/>**NOT_SET** - По умолчанию<br/>**TRUE** - Включить | Отображение огня |

<h3 id=entity_set_warden_anger_level>
  <code>entity::set_warden_anger_level</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить уровень гнева Хранителя\
**Тип:** Действие без значения\
**Описание:** Устанавливает определённый уровень гнева Хранителя на указанное существо.\
**Дополнительная информация:**\
&nbsp;&nbsp;Если уровень гнева на сущность достигает 80, Хранитель начинает активно преследовать её.\
**Работает с:**\
&nbsp;&nbsp;Хранителями

**Пример использования:**
```ts
entity::set_warden_anger_level("name_or_uuid", 1);

//Или в сухую по ключам

entity::set_warden_anger_level(name_or_uuid="name_or_uuid", anger=1);
```

**Аргументы:**

| ID           | Тип   | Описание                    |
|--------------|-------|-----------------------------|
| name_or_uuid | Текст | Имя или UUID сущности       |
| anger        | Число | Уровень гнева (от 0 до 150) |

<h3 id=entity_set_warden_digging>
  <code>entity::set_warden_digging</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить Вардену тип копания\
**Тип:** Действие без значения\
**Описание:** Устанавливает Вардену тип копания.\
**Работает с:**\
&nbsp;&nbsp;Варденом

**Пример использования:**
```ts
entity::set_warden_digging("DIG_DOWN");

//Или в сухую по ключам

entity::set_warden_digging(digging="DIG_DOWN");
```

**Аргументы:**

| ID      | Тип                                                              | Описание          |
|---------|------------------------------------------------------------------|-------------------|
| digging | Маркер<br/>**DIG_DOWN** - Закапывание<br/>**EMERGE** - Появление | Состояние копания |

<h3 id=entity_set_waypoint_color>
  <code>entity::set_waypoint_color</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить цвет значка на локаторе\
**Тип:** Действие без значения\
**Описание:** Устанавливает сущности цвет значка, отображаемого на локаторе.\
**Дополнительная информация:**\
&nbsp;&nbsp;Для работы действия, игровое значение "Видимость локатора" должно быть включено.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::set_waypoint_color(1, 2, 3);

//Или в сухую по ключам

entity::set_waypoint_color(red=1, green=2, blue=3);
```

**Аргументы:**

| ID    | Тип   | Описание        |
|-------|-------|-----------------|
| red   | Число | Красный (0-255) |
| green | Число | Зелёный (0-255) |
| blue  | Число | Синий (0-255)   |

<h3 id=entity_set_waypoint_style>
  <code>entity::set_waypoint_style</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить стиль значка на локаторе\
**Тип:** Действие без значения\
**Описание:** Устанавливает сущности стиль значка, отображаемого на локаторе.\
**Дополнительная информация:**\
&nbsp;&nbsp;Для работы действия, игровое значение "Видимость локатора" должно быть включено.\
&nbsp;&nbsp;По умолчанию в игре есть два стиля для значка: "minecraft:default" и "minecraft:bowtie".\
&nbsp;&nbsp;Оставьте аргумент "Ключ стиля" пустым, чтобы вернуть значение по умолчанию.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::set_waypoint_style("style");

//Или в сухую по ключам

entity::set_waypoint_style(style="style");
```

**Аргументы:**

| ID    | Тип   | Описание   |
|-------|-------|------------|
| style | Текст | Ключ стиля |

<h3 id=entity_set_wearing_saddle>
  <code>entity::set_wearing_saddle</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить видимость седла\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу седло.\
**Работает с:**\
&nbsp;&nbsp;Свиньями\
&nbsp;&nbsp;Лошадьми\
&nbsp;&nbsp;Лавомерками

**Пример использования:**
```ts
entity::set_wearing_saddle("FALSE");

//Или в сухую по ключам

entity::set_wearing_saddle(wearing="FALSE");
```

**Аргументы:**

| ID      | Тип                                                      | Описание      |
|---------|----------------------------------------------------------|---------------|
| wearing | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Наличие седла |

<h3 id=entity_set_wither_invulnerability_ticks>
  <code>entity::set_wither_invulnerability_ticks</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить неуязвимость иссушителю\
**Тип:** Действие без значения\
**Описание:** Устанавливает длительность неуязвимости иссушителю.\
**Работает с:**\
&nbsp;&nbsp;Иссушителем

**Пример использования:**
```ts
entity::set_wither_invulnerability_ticks(1);

//Или в сухую по ключам

entity::set_wither_invulnerability_ticks(ticks=1);
```

**Аргументы:**

| ID    | Тип   | Описание                            |
|-------|-------|-------------------------------------|
| ticks | Число | Длительность неуязвимости (в тиках) |

<h3 id=entity_set_wolf_sound_variant>
  <code>entity::set_wolf_sound_variant</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить звук Волка\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип издаваемых звуков волку.\
**Работает с:**\
&nbsp;&nbsp;Волками

**Пример использования:**
```ts
entity::set_wolf_sound_variant("ANGRY");

//Или в сухую по ключам

entity::set_wolf_sound_variant(sound_variant="ANGRY");
```

**Аргументы:**

| ID            | Тип                                                                                                                                                                       | Описание              |
|---------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------|
| sound_variant | Маркер<br/>**ANGRY** - Злой<br/>**BIG** - Большой<br/>**CLASSIC** - Обычный<br/>**CUTE** - Добрый<br/>**GRUMPY** - Сварливый<br/>**PUGLIN** - Мопс<br/>**SAD** - Грустный | Тип издаваемых звуков |

<h3 id=entity_set_wolf_type>
  <code>entity::set_wolf_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип волка\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип волка.\
**Работает с:**\
&nbsp;&nbsp;Волками

**Пример использования:**
```ts
entity::set_wolf_type("ASHEN");

//Или в сухую по ключам

entity::set_wolf_type(wolf_type="ASHEN");
```

**Аргументы:**

| ID        | Тип                                                                                                                                                                                                                | Описание  |
|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------|
| wolf_type | Маркер<br/>**ASHEN** - Пепельный<br/>**SNOWY** - Снежный<br/>**RUSTY** - Рыжий<br/>**BLACK** - Чёрный<br/>**CHESTNUT** - Каштановый<br/>**SPOTTED** - Пятнистый<br/>**STRIPED** - Полосатый<br/>**PALE** - Обычный | Тип волка |

<h3 id=entity_set_zombie_arms_raised>
  <code>entity::set_zombie_arms_raised</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить поднятие рук зомби\
**Тип:** Действие без значения\
**Описание:** Устанавливает анимацию поднятия рук для зомби.\
**Работает с:**\
&nbsp;&nbsp;Зомби

**Пример использования:**
```ts
entity::set_zombie_arms_raised("FALSE");

//Или в сухую по ключам

entity::set_zombie_arms_raised(arms_raised="FALSE");
```

**Аргументы:**

| ID          | Тип                                                      | Описание     |
|-------------|----------------------------------------------------------|--------------|
| arms_raised | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Поднятие рук |

<h3 id=entity_set_zombie_nautilus_variant>
  <code>entity::set_zombie_nautilus_variant</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить тип зомби-наутилуса\
**Тип:** Действие без значения\
**Описание:** Устанавливает тип зомби-наутилуса.\
**Работает с:**\
&nbsp;&nbsp;Зомби-наутилусами

**Пример использования:**
```ts
entity::set_zombie_nautilus_variant("TEMPERATE");

//Или в сухую по ключам

entity::set_zombie_nautilus_variant(variant="TEMPERATE");
```

**Аргументы:**

| ID      | Тип                                                        | Описание            |
|---------|------------------------------------------------------------|---------------------|
| variant | Маркер<br/>**TEMPERATE** - Умеренный<br/>**WARM** - Тёплый | Тип зомби-наутилуса |

<h3 id=entity_shear>
  <code>entity::shear</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Подстричь сущность\
**Тип:** Действие без значения\
**Описание:** Стрижёт сущность.\
**Работает с:**\
&nbsp;&nbsp;Овцами\
&nbsp;&nbsp;Грибными коровами\
&nbsp;&nbsp;Болотником\
&nbsp;&nbsp;Снеговиками

**Пример использования:**
```ts
entity::shear();
```

<h3 id=entity_shear_sheep>
  <code>entity::shear_sheep</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Подстричь овцу\
**Тип:** Действие без значения\
**Описание:** Подстригает овцу.\
**Работает с:**\
&nbsp;&nbsp;Овцами

**Пример использования:**
```ts
entity::shear_sheep();
```

<h3 id=entity_sleep>
  <code>entity::sleep</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Установить анимацию сна\
**Тип:** Действие без значения\
**Описание:** Устанавливает существу анимацию сна. Лучше всего использовать это действие в цикле.\
**Работает с:**\
&nbsp;&nbsp;Лисами

**Пример использования:**
```ts
entity::sleep("FALSE");

//Или в сухую по ключам

entity::sleep(sleep="FALSE");
```

**Аргументы:**

| ID    | Тип                                                      | Описание  |
|-------|----------------------------------------------------------|-----------|
| sleep | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить | Режим сна |

<h3 id=entity_swing_hand>
  <code>entity::swing_hand</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Проиграть анимацию взмаха руки\
**Тип:** Действие без значения\
**Описание:** Проигрывает для сущности анимацию взмаха руки.

**Пример использования:**
```ts
entity::swing_hand("MAIN");

//Или в сухую по ключам

entity::swing_hand(hand_type="MAIN");
```

**Аргументы:**

| ID        | Тип                                                        | Описание |
|-----------|------------------------------------------------------------|----------|
| hand_type | Маркер<br/>**MAIN** - Главная<br/>**OFF** - Второстепенная | Тип руки |

<h3 id=entity_teleport>
  <code>entity::teleport</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Телепортация\
**Тип:** Действие без значения\
**Описание:** Телепортирует существо в выбранное местоположение.

**Пример использования:**
```ts
entity::teleport(location(0,0,0,0,0), "FALSE");

//Или в сухую по ключам

entity::teleport(location=location(0,0,0,0,0), keep_rotation="FALSE");
```

**Аргументы:**

| ID            | Тип                                                      | Описание                 |
|---------------|----------------------------------------------------------|--------------------------|
| location      | Местоположение                                           | Новая позиция            |
| keep_rotation | Маркер<br/>**FALSE** - Выключено<br/>**TRUE** - Включено | Оставить текущий поворот |

<h3 id=entity_use_item>
  <code>entity::use_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Использовать предмет\
**Тип:** Действие без значения\
**Описание:** Инструктирует ИИ существа на использование предмета в его руке.\
**Работает с:**\
&nbsp;&nbsp;Мобами

**Пример использования:**
```ts
entity::use_item("MAIN_HAND", "FALSE");

//Или в сухую по ключам

entity::use_item(hand="MAIN_HAND", enable="FALSE");
```

**Аргументы:**

| ID     | Тип                                                                             | Описание      |
|--------|---------------------------------------------------------------------------------|---------------|
| hand   | Маркер<br/>**MAIN_HAND** - Основная рука<br/>**OFF_HAND** - Второстепенная рука | Тип руки      |
| enable | Маркер<br/>**FALSE** - Выключить<br/>**TRUE** - Включить                        | Использование |

<h3 id=if_entity_collides_at_location>
  <code>entity::collides_at_location</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сталкивается на местоположении\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, сталкивается ли сущность с блоками, шалкерами, лодками и границей мира на указанном местоположении.

**Пример использования:**
```ts
if(entity::collides_at_location(location(0,0,0,0,0))){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::collides_at_location(location=location(0,0,0,0,0))){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID       | Тип            | Описание                    |
|----------|----------------|-----------------------------|
| location | Местоположение | Местоположение для проверки |

<h3 id=if_entity_collides_using_hitbox>
  <code>entity::collides_using_hitbox</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сталкивается используя кастомный хитбокс\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, сталкивается ли сущность с блоками, шалкерами, лодками и границей мира используя кастомный хитбокс.

**Пример использования:**
```ts
if(entity::collides_using_hitbox(location(0,0,0,0,0), location(0,0,0,0,0))){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::collides_using_hitbox(min=location(0,0,0,0,0), max=location(0,0,0,0,0))){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID  | Тип            | Описание             |
|-----|----------------|----------------------|
| min | Местоположение | Первый угол хитбокса |
| max | Местоположение | Второй угол хитбокса |

<h3 id=if_entity_collides_with_entity>
  <code>entity::collides_with_entity</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сталкивается с сущностью\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, сталкивается ли хитбокс сущности с хитбоксом другой указанной сущности.

**Пример использования:**
```ts
if(entity::collides_with_entity("name_or_uuid", "CONTAINS")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::collides_with_entity(name_or_uuid="name_or_uuid", check_type="CONTAINS")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID           | Тип                                                                | Описание                  |
|--------------|--------------------------------------------------------------------|---------------------------|
| name_or_uuid | Текст                                                              | Имя или UUID сущности     |
| check_type   | Маркер<br/>**CONTAINS** - Содержит<br/>**OVERLAPS** - Пересекается | Тип проверки столкновения |

<h3 id=if_entity_dummy>
  <code>entity::is_dummy</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** ...\
**Тип:** Действие, проверяющее условие\
**Описание:** ...

**Пример использования:**
```ts
if(entity::is_dummy()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_exists>
  <code>entity::exists</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Существует\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, находится ли существо в мире.

**Пример использования:**
```ts
if(entity::exists()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_has_custom_tag>
  <code>entity::has_custom_tag</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Имеет кастомный тег\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, имеет ли существо кастомный тег с указанным значением.

**Пример использования:**
```ts
if(entity::has_custom_tag("tag", ["tag_value", "tag_value"], "CONTAINS")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::has_custom_tag(tag="tag", tag_value=["tag_value", "tag_value"], compare_type="CONTAINS")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID           | Тип                                                                                                                                              | Описание                                                   |
|--------------|--------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------|
| tag          | Текст                                                                                                                                            | Название тега                                              |
| tag_value    | Список\[Текст\]                                                                                                                                  | Значение тега<br/>Аргумент поддерживает разложение списков |
| compare_type | Маркер<br/>**CONTAINS** - Содержит<br/>**ENDS_WITH** - Заканчивается на<br/>**EQUALS** - Точное соответствие<br/>**STARTS_WITH** - Начинается на | Тип сравнения                                              |

<h3 id=if_entity_has_potion_effect>
  <code>entity::has_potion_effect</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Имеет эффект от зелья\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, имеет ли существо эффект от зелья.

**Пример использования:**
```ts
if(entity::has_potion_effect([potion("slow_falling"), potion("slow_falling")], "ALL")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::has_potion_effect(potions=[potion("slow_falling"), potion("slow_falling")], check_mode="ALL")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID         | Тип                                                         | Описание                                                        |
|------------|-------------------------------------------------------------|-----------------------------------------------------------------|
| potions    | Список\[Зелье\]                                             | Зелья для проверки<br/>Аргумент поддерживает разложение списков |
| check_mode | Маркер<br/>**ALL** - Все эффекты<br/>**ANY** - Любой эффект | Режим проверки                                                  |

<h3 id=if_entity_in_area>
  <code>entity::in_area</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Внутри региона\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, находится ли сущность в определённом регионе.

**Пример использования:**
```ts
if(entity::in_area(location(0,0,0,0,0), location(0,0,0,0,0), "FALSE", "HITBOX", "CONTAINS")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::in_area(location_1=location(0,0,0,0,0), location_2=location(0,0,0,0,0), ignore_y_axis="FALSE", intersect_type="HITBOX", check_type="CONTAINS")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID             | Тип                                                                | Описание              |
|----------------|--------------------------------------------------------------------|-----------------------|
| location_1     | Местоположение                                                     | Первый угол региона   |
| location_2     | Местоположение                                                     | Второй угол региона   |
| ignore_y_axis  | Маркер<br/>**FALSE** - Не игнорировать<br/>**TRUE** - Игнорировать | Игнорировать ось Y    |
| intersect_type | Маркер<br/>**HITBOX** - Хитбокс<br/>**POINT** - Местоположение     | Тип пересечения       |
| check_type     | Маркер<br/>**CONTAINS** - Содержит<br/>**OVERLAPS** - Пересекается | Тип проверки хитбокса |

<h3 id=if_entity_is_disguised>
  <code>entity::is_disguised</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Замаскирована\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, замаскирована ли сущность.

**Пример использования:**
```ts
if(entity::is_disguised()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_is_grounded>
  <code>entity::is_grounded</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Касается поверхности блока\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, касается ли существо поверхности блока.

**Пример использования:**
```ts
if(entity::is_grounded()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_is_item>
  <code>entity::is_item</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Является предметом\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, является ли существо предметом.

**Пример использования:**
```ts
if(entity::is_item()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_is_minecraft_tagged>
  <code>entity::is_minecraft_tagged</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Имеет Minecraft-тег\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, имеет ли сущность указанный Minecraft-тег (например, "aquatic").\
**Дополнительная информация:**\
&nbsp;&nbsp;Minecraft-тег должен начинаться с "#minecraft:"

**Пример использования:**
```ts
if(entity::is_minecraft_tagged("namespace")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::is_minecraft_tagged(namespace="namespace")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID        | Тип   | Описание      |
|-----------|-------|---------------|
| namespace | Текст | Minecraft-тег |

<h3 id=if_entity_is_mob>
  <code>entity::is_mob</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Является мобом\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, является ли существо мобом.

**Пример использования:**
```ts
if(entity::is_mob()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_is_near_location>
  <code>entity::is_near_location</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Рядом с местоположением\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, находится ли существо рядом с указанным местоположением.

**Пример использования:**
```ts
if(entity::is_near_location(1, location(0,0,0,0,0), "FALSE")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::is_near_location(range=1, location=location(0,0,0,0,0), ignore_y_axis="FALSE")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID            | Тип                                                                | Описание                    |
|---------------|--------------------------------------------------------------------|-----------------------------|
| range         | Число                                                              | Радиус проверки             |
| location      | Местоположение                                                     | Местоположение для проверки |
| ignore_y_axis | Маркер<br/>**FALSE** - Не игнорировать<br/>**TRUE** - Игнорировать | Игнорировать ось Y          |

<h3 id=if_entity_is_projectile>
  <code>entity::is_projectile</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Является снарядом\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, является ли существо снарядом.

**Пример использования:**
```ts
if(entity::is_projectile()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_is_riding_entity>
  <code>entity::is_riding_entity</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Сущность оседлала сущность\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, оседлала ли сущность любую из других указанных сущностей.

**Пример использования:**
```ts
if(entity::is_riding_entity(["entity_ids", "entity_ids"], "FARTHEST")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::is_riding_entity(entity_ids=["entity_ids", "entity_ids"], compare_mode="FARTHEST")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID           | Тип                                                                                                                                                                                                                                                                                          | Описание                                                            |
|--------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------|
| entity_ids   | Список\[Текст\]                                                                                                                                                                                                                                                                              | Имя или UUID сущностей<br/>Аргумент поддерживает разложение списков |
| compare_mode | Маркер<br/>**FARTHEST** - creative_plus.action.if_entity_is_riding_entity.argument.compare_mode.enum.farthest.name<br/>**NAME_OR_UUID** - Имя или UUID<br/>**NEAREST** - creative_plus.action.if_entity_is_riding_entity.argument.compare_mode.enum.nearest.name<br/>**TYPE** - Тип существа | Режим проверки                                                      |

<h3 id=if_entity_is_standing_on_block>
  <code>entity::is_standing_on_block</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Стоит на блоке\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, стоит ли сущность на определённом блоке или местоположении.

**Пример использования:**
```ts
if(entity::is_standing_on_block(["minecraft:oak_log[axis=x]", "minecraft:oak_log[axis=x]"], [location(0,0,0,0,0), location(0,0,0,0,0)], "FALSE")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::is_standing_on_block(blocks=["minecraft:oak_log[axis=x]", "minecraft:oak_log[axis=x]"], locations=[location(0,0,0,0,0), location(0,0,0,0,0)], only_solid="FALSE")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID         | Тип                                                          | Описание                                                                 |
|------------|--------------------------------------------------------------|--------------------------------------------------------------------------|
| blocks     | Список\[Блок\]                                               | Блоки для проверки<br/>Аргумент поддерживает разложение списков          |
| locations  | Список\[Местоположение\]                                     | Местоположения для проверки<br/>Аргумент поддерживает разложение списков |
| only_solid | Маркер<br/>**FALSE** - Учитывать<br/>**TRUE** - Не учитывать | Учитывать проходимые блоки                                               |

<h3 id=if_entity_is_type>
  <code>entity::is_type</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Тип существа равен\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, равен ли тип существа типу в сундуке.

**Пример использования:**
```ts
if(entity::is_type([item("stick"), item("stick")])){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::is_type(entity_types=[item("stick"), item("stick")])){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID           | Тип               | Описание                                                  |
|--------------|-------------------|-----------------------------------------------------------|
| entity_types | Список\[Предмет\] | Тип существа<br/>Аргумент поддерживает разложение списков |

<h3 id=if_entity_is_undead>
  <code>entity::is_undead</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Является нежитью\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, является ли существо нежитью.

**Пример использования:**
```ts
if(entity::is_undead()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_is_vehicle>
  <code>entity::is_vehicle</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Является транспортом\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, является ли существо транспортом.

**Пример использования:**
```ts
if(entity::is_vehicle()){
    player::message("Условие верно");
}
```

<h3 id=if_entity_name_equals>
  <code>entity::name_equals</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Имя равно\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, равно ли имя существа имени в сундуке.

**Пример использования:**
```ts
if(entity::name_equals(["names_or_uuids", "names_or_uuids"])){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::name_equals(names_or_uuids=["names_or_uuids", "names_or_uuids"])){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID             | Тип             | Описание                                                                 |
|----------------|-----------------|--------------------------------------------------------------------------|
| names_or_uuids | Список\[Текст\] | Имена или UUID для проверки<br/>Аргумент поддерживает разложение списков |

<h3 id=if_entity_spawn_reason_equals>
  <code>entity::spawn_reason_equals</code>
  <a href="#" style="font-size: 12px; margin-left:">⬆️</a>
</h3>

**Имя:** Причина появления равна\
**Тип:** Действие, проверяющее условие\
**Описание:** Проверяет, равна ли причина появления существа определённому значению.

**Пример использования:**
```ts
if(entity::spawn_reason_equals("BEEHIVE")){
    player::message("Условие верно");
}

//Или в сухую по ключам

if(entity::spawn_reason_equals(reason="BEEHIVE")){
    player::message("Условие верно");
}
```

**Аргументы:**

| ID     | Тип                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                          | Описание       |
|--------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|
| reason | Маркер<br/>**BEEHIVE** - Появление из улья<br/>**BREEDING** - От размножения<br/>**BUILD_IRONGOLEM** - От постройки Железного голема<br/>**BUILD_SNOWMAN** - От постройки Снежного голема<br/>**BUILD_WITHER** - От постройки Иссушителя<br/>**COMMAND** - От команды<br/>**CURED** - Вылечивание Жителя<br/>**CUSTOM** - Кастомная<br/>**DEFAULT** - Стандартная<br/>**DISPENSE_EGG** - Появление из Раздатчика<br/>**DROWNED** - От утопления<br/>**EGG** - Появление из яйца<br/>**ENDER_PEARL** - Появление из Жемчуга Энда<br/>**EXPLOSION** - После взрыва<br/>**FROZEN** - От заморозки<br/>**INFECTION** - От заражения Зомби<br/>**JOCKEY** - Как жокей сущности<br/>**LIGHTNING** - От молнии<br/>**MOUNT** - Как транспорт сущности<br/>**NATURAL** - Натуральный спавн<br/>**NETHER_PORTAL** - Из портала в Незер<br/>**OCELOT_BABY** - Ребёнок Оцелота<br/>**PATROL** - Патруль Разбойников<br/>**PIGLIN_ZOMBIFIED** - Зомбифицирование<br/>**RAID** - От рейда<br/>**REINFORCEMENTS** - Подкрепление<br/>**SHEARED** - От подстригания<br/>**SHOULDER_ENTITY** - Спрыгивание с плеча<br/>**SILVERFISH_BLOCK** - Из блока<br/>**SLIME_SPLIT** - Разделение Слизней<br/>**SPAWNER** - Со спавнера мобов<br/>**SPAWNER_EGG** - Из яйца Призыва<br/>**TRAP** - Ловушка<br/>**VILLAGER_DEFENSE** - Защита деревни<br/>**VILLAGE_INVASION** - Наступление на деревню | Причина спавна |

